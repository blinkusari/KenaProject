<?php
/**
 * Sale badge template
 */

global $post, $product;

$product = wc_get_product();

if ( empty( $product ) ) {
	return;
}
if ( $product->is_on_sale() ) :
	$settings = $this->get_settings();
	$badge_text='';
	$percent=0;
	$numeric=0;
	if (!$product->is_type('grouped')) {
		$regular_price = $product->get_regular_price();
		$sale_price = $product->get_sale_price();
		if ($product->has_child()) {
			$variation_prices = $product->get_variation_prices();
			foreach ($variation_prices['price'] as $id => $value) {
				$new_percent = round((($variation_prices['regular_price'][$id] - $value) / $variation_prices['regular_price'][$id]) * 100);
				if ($new_percent > $percent) {
					$numeric=$variation_prices['regular_price'][$id] - $value;
					$percent = $new_percent;
				}
			}
			$regular_price = $product->get_variation_regular_price('max', true);
		} else {
			$numeric=$regular_price - $sale_price;
			$percent = round(($numeric / $regular_price) * 100);
		}
	}
	if($settings['display_type']=='label'){
		$badge_text=$settings['single_badge_text'];
	}elseif($settings['display_type']=='percent' || $settings['display_type']=='percent_label'){
		$badge_text=$percent.'%';
	}else{
		$badge_text=$numeric;
	}
	if($settings['display_type']=='percent_label'){
		$badge_text.=" ".$settings['single_badge_text'];
	}
	?>

	<?php echo apply_filters( 'woocommerce_sale_flash', '<span class="onsale">' . esc_html($badge_text) . '</span>', $post, $product ); ?>

<?php
	endif;