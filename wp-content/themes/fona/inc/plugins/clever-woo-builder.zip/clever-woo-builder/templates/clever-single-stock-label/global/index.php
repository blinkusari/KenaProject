<?php
/**
 * Stock label template
 */

global $product;
add_filter( 'woocommerce_get_stock_html', '__return_empty_string' );
$availability = $product->get_availability();
$label= $availability['availability']==''?esc_html__('In stock','clever-woo-builder'):$availability['availability'];
$html='<p class="cwb-single-stock-label stock '. $availability['class'].'">'.wp_kses_post( $label ).'</p>';
echo apply_filters( 'zoo_get_stock_html', $html);