<?php
/**
 * Loop item tags
 */

$settings = $this->get_settings();

if( isset( $settings['show_wishlist'] ) ){
	if ( 'yes' === $settings['show_wishlist'] ) {
		do_action( 'clever-woo-builder/templates/clever-woo-products-list/wishlist-button', $settings );
	}
}
