<?php
/**
 * Single Products in Category
 */
global $product, $post;

$product = wc_get_product();

if ( empty( $product ) ) {
    return;
}
$term_list = wp_get_post_terms($product->get_id(),'product_cat');
$slugs=[];
foreach ($term_list as $cat) {
    $slugs[]=$cat->slug;
}
$settings = $this->get_settings();
$number = $settings['product_number'];
$layout = $settings['layout'];

$slider_json_config = '{
        "slidesToShow": "' . $settings['cols']['size'] . '",
        "slidesToShow_table": "' . $settings['cols_tablet']['size'] . '",
        "slidesToShow_mobile": "' . $settings['cols_mobile']['size'] . '",
        "arrows":"' . $settings['arrows'] . '",
        "arrow_left":"' . $settings['arrow_left'] . '",
        "arrow_right":"' . $settings['arrow_right'] . '",        
        "dots":"' . $settings['dots'] . '"
        }';
$wc_attr = array(
    'posts_per_page' => $number,
    'no_found_rows' => 1,
    'post_status' => 'publish',
    'post_type' => 'product',
    'product_cat' => implode(',', $slugs),
);
if ('yes' === get_option('woocommerce_hide_out_of_stock_items')) {
    $wc_attr['tax_query'] = array(
        array(
            'taxonomy' => 'product_visibility',
            'field' => 'name',
            'terms' => 'outofstock',
            'operator' => 'NOT IN',
        ),
    );
}
switch ($settings['asset_type']) {
    case 'featured':
        $meta_query[] = array(
            array(
                'taxonomy' => 'product_visibility',
                'field'    => 'name',
                'terms'    => 'featured',
                'operator' => 'IN'
            ),
        );
        $wc_attr['tax_query'] = $meta_query;
        break;
    case 'onsale':
        $product_ids_on_sale = wc_get_product_ids_on_sale();
        $wc_attr['post__in'] = $product_ids_on_sale;
        break;
    case 'best-selling':
        $wc_attr['meta_key'] = 'total_sales';
        $wc_attr['orderby']  = 'meta_value_num';
        break;
    case 'latest':
        $wc_attr['orderby'] = 'date';
        break;
    case 'toprate':
        $wc_attr['orderby'] = 'meta_value_num';
        $wc_attr['meta_key'] = '_wc_average_rating';
        $wc_attr['order'] = 'DESC';
        break;
    case 'deal':
        $product_ids_on_sale = wc_get_product_ids_on_sale();
        $wc_attr['post__in'] = $product_ids_on_sale;
        $wc_attr['meta_query'] = array(
            'relation' => 'AND',
            array(
                'key' => '_sale_price_dates_to',
                'value' => time(),
                'compare' => '>'
            )
        );
        break;
    default:
        break;
}


$the_query = new WP_Query($wc_attr);
if ($the_query->have_posts()) {
    $wrap_class = 'products ' . $layout . ' ' . $layout . '-layout cwb-products-in-category';
    if ($layout == 'carousel') {
        $wrap_class .= ' cwb-carousel';
    }
    if (function_exists('zoo_product_hover_effect')) {
        $wrap_class .= ' hover-effect-' . zoo_product_hover_effect();
    }
    if($settings['title']!=''){
        ?>
        <h2>
            <?php echo esc_html($settings['title'])?>
        </h2>
        <?php
    }
    ?>
    <ul class="<?php echo esc_attr($wrap_class) ?>" data-cwb-config="<?php echo esc_attr($slider_json_config) ?>">
        <?php
        while ($the_query->have_posts()) {
            $the_query->the_post();
            wc_get_template_part('content', 'product');
        }
        ?>
    </ul>
    <?php
}

wp_reset_postdata();