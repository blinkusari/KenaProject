<?php
/**
 * Taxonomy item template
 */

$settings      = $this->get_settings();
$title         = clever_woo_builder_tools()->trim_text( $taxonomy->name, $settings['title_length'], 'word', '...' );
$title_tag     = isset( $settings['title_html_tag'] ) ? $settings['title_html_tag'] : 'h5';
$description   = clever_woo_builder_tools()->trim_text( $taxonomy->description, $settings['desc_length'], 'symbols', '...' );
$count_before  = ! is_rtl() ? $settings['count_before_text'] : $settings['count_after_text'];
$count_after   = ! is_rtl() ? $settings['count_after_text'] : $settings['count_before_text'];
$thumbnail_key = apply_filters( 'clever-woo-builder/clever-woo-taxonomy-tiles/tax_thumbnail', 'thumbnail_id', $taxonomy );

?>
<div class="clever-woo-taxonomy-item">
	<div class="clever-woo-taxonomy-item__box" <?php $this->__get_tax_bg( $taxonomy, $thumbnail_key ); ?>>
		<div class="clever-woo-taxonomy-item__box-content"> <div class="clever-woo-taxonomy-item__box-inner"><?php
			if ( '' !== $title ) {
				echo sprintf('<%s class="clever-woo-taxonomy-item__box-title">%s</%s>', esc_attr($title_tag), esc_html($title), esc_attr($title_tag));
			}

			if ( 'yes' === $settings['show_taxonomy_count'] ) {
				echo sprintf( '<div class="clever-woo-taxonomy-item__box-count">%2$s%1$s%3$s</div>', $taxonomy->count, $count_before, $count_after );
			}

			if ( '' !== $description ) {
				echo sprintf( '<div class="clever-woo-taxonomy-item__box-description">%s</div>', $description );
			}
		?></div></div>
		<a href="<?php echo esc_url( get_category_link( $taxonomy->term_id ) ) ?>" class="clever-woo-taxonomy-item__box-link"></a>
	</div>
</div>