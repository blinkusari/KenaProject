<?php
/**
 * Loop item title
 */

$sku = clever_woo_builder_template_functions()->get_product_sku();

if ( 'yes' !== $this->get_attr( 'show_sku' ) || '' === $sku ) {
	return;
}
?>

<div class="clever-woo-product-sku"><?php echo esc_html($sku); ?></div>