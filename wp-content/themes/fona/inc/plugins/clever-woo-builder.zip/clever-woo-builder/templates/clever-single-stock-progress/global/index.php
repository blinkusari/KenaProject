<?php
/**
 * Stock label template
 */


global $post, $product;
$settings = $this->get_settings();
$allow_show = true;
if ($settings['single_stock_progress_apply_sale']) {
    $cwb_date_sale = get_post_meta(get_the_ID(), '_sale_price_dates_to', true);
    if ($product->is_on_sale() && $cwb_date_sale > time()) {
        $allow_show = true;
    } else {
        $allow_show = false;
    }
}
if ($allow_show) :
    if (is_single()) {
        $cwb_base_stock = get_post_meta(get_the_ID(), '_cwb_number_product_on_event', true);
        $stock = $product->get_stock_quantity();
        if ($cwb_base_stock != 0 && $stock != NULL) {
            $stock_parse = '';
            $loading_percent = ($stock / $cwb_base_stock) * 100;
            if ($loading_percent < 40) {
                $stock_parse = 'final-parse';
            } elseif ($loading_percent >= 40 && $loading_percent < 80) {
                $stock_parse = 'second-parse';
            } else {
                $stock_parse = 'first-parse';
            }
            ?>
            <div class="cwb-stock-progress">
                <span class="cwb-label-product-stock-progress">
                    <?php printf(esc_html__('Hurry! Only ', 'elementor-theme') . '<b class="number-product">%s</b>' . esc_html__(' left in stock:', 'elementor-theme'), $stock); ?>
                </span>
                <div class="cwb-stock-progress-bar">
                        <span class="inner-stock-progress-bar <?php echo esc_attr($stock_parse) ?>"
                              style="width:<?php echo esc_attr($loading_percent) ?>%"></span>
                </div>
            </div>
            <?php
        }
    }
endif;