<?php
/**
 * Product title template
 */
$settings = $this->get_settings();
global $product;
$availability = $product->get_availability();
if ( $availability['class'] != 'out-of-stock' || \Elementor\Plugin::$instance->editor->is_edit_mode()) {
    $fake_data     = intval( $settings['product_min'] );
    $fake_max_data = intval( $settings['product_max'] );
    if ( $fake_max_data > $fake_data ) {
        $sold = rand( $fake_data, $fake_max_data );
        ?>
        <div class="cwb-sold-in-day">
            <i class="<?php echo esc_attr($settings['icon']); ?>">
            </i>
            <span class="total-product-sold"><?php echo esc_attr( $sold ); ?></span>
            <?php
            echo esc_html__( 'sold in last', 'clever-woo-builder' );
            ?>
            <span class="current-hours"> <?php print date( 'H' );
                echo esc_html__( ' hours', 'clever-woo-builder' ) ?></span>
        </div>
        <?php
    }
}
?>
