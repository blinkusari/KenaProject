<?php
/**
 * Loop item thumbnail
 */

$settings = $this->get_settings();
$size = $this->get_attr( 'thumb_size' );
$thumbnail = clever_woo_builder_template_functions()->get_product_thumbnail( $size );
$open_link  = '';
$close_link = '';

if ( 'yes' !== $this->get_attr( 'show_image' ) || null === $thumbnail ) {
	return;
}

if ( isset( $settings['is_linked_image'] ) && 'yes' === $settings['is_linked_image'] ) {
	$open_link  = '<a href="' . get_permalink() . '">';
	$close_link = '</a>';
}
?>

<div class="clever-woo-product-thumbnail"><?php
	do_action('clever-woo-builder/templates/products-list/before-item-thumbnail');
    $allow_html=array('a'=>array('class'=>array(),'href'=>array()));
	echo wp_kses($open_link,$allow_html);
	echo wp_kses_post($thumbnail);
	echo wp_kses($close_link,$allow_html);;
	do_action('clever-woo-builder/templates/products-list/after-item-thumbnail');
	?></div>