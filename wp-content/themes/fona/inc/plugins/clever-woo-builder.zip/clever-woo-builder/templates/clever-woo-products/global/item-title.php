<?php
/**
 * Loop item title
 */

$title = clever_woo_builder_template_functions()->get_product_title();
$title      = clever_woo_builder_tools()->trim_text(
	$title,
	$this->get_attr( 'title_length' ),
	$this->get_attr( 'title_trim_type' ),
	'...'
);
$title_link = clever_woo_builder_template_functions()->get_product_title_link();
$title_tag  = ! empty( $this->get_attr( 'title_html_tag' ) ) ? $this->get_attr( 'title_html_tag' ) : 'h5';

if ( 'yes' !== $this->get_attr( 'show_title' ) || '' === $title ) {
	return;
}

echo sprintf('<%s class="clever-woo-product-title"><a href="%s" rel="bookmark">%s</a></%s>', esc_attr($title_tag), esc_url($title_link), esc_html($title), esc_attr($title_tag));
