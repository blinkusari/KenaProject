<?php
/**
 * Categories loop item layout 3
 */

?>

<?php include $this->get_template( 'item-thumb' ); ?>
<div class="clever-woo-categories-content">
	<div class="clever-woo-categories-title__wrap"><?php
	  include $this->get_template( 'item-title' );
	  include $this->get_template( 'item-count' );
	  ?></div><?php
	include $this->get_template( 'item-description' );
	?></div>