<?php
/**
 * Single Recent Product Viewed
 */
$settings = $this->get_settings();
$viewed_products = !empty($_COOKIE['woocommerce_recently_viewed']) ? (array)explode('|', wp_unslash(str_replace(get_the_ID(), '', $_COOKIE['woocommerce_recently_viewed']))) : array();
$viewed_products = array_reverse(array_filter(array_map('absint', $viewed_products)));

if (empty($viewed_products)) {
    return;
}

$number = $settings['product_number'];
$layout = $settings['layout'];

$slider_json_config = '{
        "slidesToShow": "' . $settings['cols']['size'] . '",
        "slidesToShow_table": "' . $settings['cols_tablet']['size'] . '",
        "slidesToShow_mobile": "' . $settings['cols_mobile']['size'] . '",
        "arrows":"' . $settings['arrows'] . '",
        "arrow_left":"' . $settings['arrow_left'] . '",
        "arrow_right":"' . $settings['arrow_right'] . '",        
        "dots":"' . $settings['dots'] . '"
        }';
$query_args = array(
    'posts_per_page' => $number,
    'no_found_rows' => 1,
    'post_status' => 'publish',
    'post_type' => 'product',
    'post__in' => $viewed_products,
    'orderby' => 'post__in',
);

if ('yes' === get_option('woocommerce_hide_out_of_stock_items')) {
    $query_args['tax_query'] = array(
        array(
            'taxonomy' => 'product_visibility',
            'field' => 'name',
            'terms' => 'outofstock',
            'operator' => 'NOT IN',
        ),
    );
}

$the_query = new WP_Query(apply_filters('woocommerce_recently_viewed_products_widget_query_args', $query_args));
if ($the_query->have_posts()) {
    $wrap_class = 'products ' . $layout . ' ' . $layout . '-layout cwb-recent-viewed-products';
    if ($layout == 'carousel') {
        $wrap_class .= ' cwb-carousel';
    }
    if (function_exists('zoo_product_hover_effect')) {
        $wrap_class .= ' hover-effect-' . zoo_product_hover_effect();
    }
    if($settings['title']!=''){
        ?>
        <h3 class="cwb-title-recent-viewed">
            <?php echo esc_html($settings['title'])?>
        </h3>
        <?php
    }
    ?>
    <ul class="<?php echo esc_attr($wrap_class) ?>" data-cwb-config="<?php echo esc_attr($slider_json_config) ?>">
        <?php
        while ($the_query->have_posts()) {
            $the_query->the_post();
            wc_get_template_part('content', 'product');
        }
        ?>
    </ul>
    <?php
}

wp_reset_postdata();