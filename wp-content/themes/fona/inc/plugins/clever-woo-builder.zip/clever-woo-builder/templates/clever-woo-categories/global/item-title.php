<?php
/**
 * Loop item title
 */

$title = $category->name;
$title_tag = ! empty( $this->get_attr( 'title_html_tag' ) ) ? $this->get_attr( 'title_html_tag' ) : 'h5';

if ( 'yes' !== $this->get_attr( 'show_title' ) ) {
	return;
}

echo sprintf('<%s class="clever-woo-category-title">', esc_attr($title_tag));
echo sprintf('<a href="%s" class="clever-woo-category-title__link">%s</a>', esc_url(clever_woo_builder_tools()->get_term_permalink( $category->term_id )), esc_html($title));
echo sprintf('</%s>', esc_attr($title_tag));
