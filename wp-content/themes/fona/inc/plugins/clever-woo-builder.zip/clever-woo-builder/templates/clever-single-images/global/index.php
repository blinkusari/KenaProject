<?php
/**
 * Images template
 */
global $product;
// Note: `wc_get_gallery_image_html` was added in WC 3.3.2 and did not exist prior. This check protects against theme overrides being used on older versions of WC.
if ( ! function_exists( 'wc_get_gallery_image_html' ) ) {
    return;
}

$settings      = $this->get_settings();
$gallery_layout=$settings['layout'];
$columns           = $settings['cols']['size'];
$columns_tablet= $settings['cols_tablet']['size']?$settings['cols_tablet']['size']:1;
$columns_mobile= $settings['cols_mobile']['size']?$settings['cols_mobile']['size']:1;
$padding_tablet = $settings['center_padding_tablet']['size']?$settings['center_padding_tablet']['size'].$settings['center_padding_tablet']['unit']:'0px';
$padding_mobile = $settings['center_padding_mobile']['size']?$settings['center_padding_mobile']['size'].$settings['center_padding_mobile']['unit']:'0px';
$slider_json_config = '{
        "slidesToShow": "' . $settings['cols']['size'] . '",
        "slidesToShow_table": "' . $columns_tablet . '",
        "slidesToShow_mobile": "' . $columns_mobile . '",
        "center_mod": "' . $settings['center_mod']. '",
        "center_padding": "' . $settings['center_padding']['size'].$settings['center_padding']['unit']. '",
        "center_padding_mobile": "' .$padding_tablet . '",
        "center_padding_mobile": "' . $padding_mobile. '",
        "arrows":"' . $settings['arrows'] . '",
        "arrow_left":"' . $settings['arrow_left'] . '",
        "arrow_right":"' . $settings['arrow_right'] . '",        
        "thumb_arrows":"' . $settings['thumb_arrows'] . '",
        "thumb_arrow_left":"' . $settings['thumb_arrow_left'] . '",
        "thumb_arrow_right":"' . $settings['thumb_arrow_right'] . '",
        "dots":"' . $settings['dots'] . '",
        "isVertical":"' . ($settings['layout']=="vertical") . '"
        }';
$post_thumbnail_id = $product->get_image_id();
$attachment_ids = $product->get_gallery_image_ids();

$thumb_pos='';
if($settings['layout']=="vertical" && $settings['thumb_right']){
    $thumb_pos='thumb-right';
}
$wrapper_classes   = apply_filters(
    'woocommerce_single_product_image_gallery_classes',
    array(
        'cwb-single-images',
        $gallery_layout.'-layout',
        $thumb_pos,
        'woocommerce-product-gallery',
        'woocommerce-product-gallery--' . ( $product->get_image_id() ? 'with-images' : 'without-images' ),
        'woocommerce-product-gallery--columns-' . absint( $columns ),
        'images',
        count($attachment_ids)>0?"with-thumb":"without-thumb"
    )
);
$thumb_images='';
$gallery_thumbnail = wc_get_image_size( 'gallery_thumbnail' );
$thumbnail_size    = apply_filters( 'woocommerce_gallery_thumbnail_size', array( $gallery_thumbnail['width'], $gallery_thumbnail['height'] ) );
?>
<div class="<?php echo esc_attr( implode( ' ', array_map( 'sanitize_html_class', $wrapper_classes ) ) ); ?>" data-slider='<?php echo esc_attr($slider_json_config)?>' data-columns="<?php echo esc_attr( $columns ); ?>">
    <figure class="woocommerce-product-gallery__wrapper">
        <div class="wrap-main-product-gallery">
            <?php
            if ( $product->get_image_id() ) {
                $html = wc_get_gallery_image_html( $post_thumbnail_id, true );
            } else {
                $html = '<div class="woocommerce-product-gallery__image--placeholder">';
                $html .= sprintf( '<img src="%s" alt="%s" class="wp-post-image" />', esc_url( wc_placeholder_img_src( 'woocommerce_single' ) ), esc_html__( 'Awaiting product image', 'woocommerce' ) );
                $html .= '</div>';
            }

            echo apply_filters( 'woocommerce_single_product_image_thumbnail_html', $html, $post_thumbnail_id );
            $thumb_images.='<li class="thumbnail-item">'.wp_get_attachment_image ( $post_thumbnail_id, $thumbnail_size, false).'</li>';
            if ( $attachment_ids && $product->get_image_id() ) {
                foreach ( $attachment_ids as $attachment_id ) {
                    echo apply_filters( 'woocommerce_single_product_image_thumbnail_html', wc_get_gallery_image_html( $attachment_id, true ), $attachment_id );
                    $thumb_images.='<li class="thumbnail-item">'.wp_get_attachment_image ( $attachment_id, $thumbnail_size, false).'</li>';
                }
            }
            ?>
        </div>
        <?php
        if ( $thumb_images && count($attachment_ids)>0) {
            if ( $gallery_layout != 'grid' && $gallery_layout != 'carousel') {
                echo sprintf(' <ul class="wrap-list-thumbnail">%s</ul>',$thumb_images);
            }
        }
        ?>
    </figure>
</div>
<?php
