<?php
/**
 * Cart page template
 */

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_before_cart' );

?>

<div class="clever-woo-builder-woocommerce-cart">
	<?php
		wc_print_notices();

		$template = apply_filters( 'clever-woo-builder/current-template/template-id', clever_woo_builder_integration_woocommerce()->get_current_cart_template() );

		echo clever_woo_builder()->parser->get_template_content( $template );
	?>
</div>

<?php

do_action('woocommerce_after_cart');
