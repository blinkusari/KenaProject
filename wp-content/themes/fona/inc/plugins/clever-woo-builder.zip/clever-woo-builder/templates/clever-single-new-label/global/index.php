<?php
/**
 * Stock label template
 */
global $product;
if ( get_post_meta( $product->get_id(), 'zoo_single_product_new', true ) == 1 ) {
    ?>
    <span class="cwb-new-label"><?php esc_html_e( 'New', 'clever-woo-builder' ); ?></span>
    <?php
}