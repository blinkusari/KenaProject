<?php
/**
 * Product title template
 */
$settings = $this->get_settings();
// Get Free Shipping Methods for Rest of the World Zone & populate array $min_amounts
$default_zone = new WC_Shipping_Zone( 0 );

$default_methods = $default_zone->get_shipping_methods();
foreach ( $default_methods as $key => $value ) {
    if ( $value->id === "free_shipping" ) {
        if ( $value->min_amount > 0 ) {
            $min_amounts[] = $value->min_amount;
        }
    }
}
// Get Free Shipping Methods for all other ZONES & populate array $min_amounts
$delivery_zones = WC_Shipping_Zones::get_zones();
foreach ( $delivery_zones as $key => $delivery_zone ) {
    foreach ( $delivery_zone['shipping_methods'] as $key => $value ) {
        if ( $value->id === "free_shipping" ) {
            if ( $value->min_amount > 0 ) {
                $min_amounts[] = $value->min_amount;
            }
        }
    }
}
// Find lowest min_amount
if ( isset( $min_amounts ) ) {
    if ( is_array( $min_amounts ) && $min_amounts ) {
        $current = WC()->cart->subtotal;
        $min_amount = min( $min_amounts );
        ?>
        <div class="cwb-free-shipping-notice-amount">
            <i class="<?php echo esc_attr($settings['icon'])?>"></i>
            <span class="extend-notice-label">
                    <?php
                    if ($current < $min_amount) {
                        echo esc_html__( 'Spend ', 'clever-woo-builder' ) . '<span class="free-shipping-amount">' . wc_price( $min_amount - $current ) . '</span>' . esc_html__( ' to get Free Shipping', 'clever-woo-builder' );
                    }else {
                        esc_html_e('Congratulations! You\'ve got free shipping!', 'clever-woo-builder');
                    }
                    ?>
                    </span>
        </div>
    <?php }
}
?>
