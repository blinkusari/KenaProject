<?php
/**
 * Products list loop end template
 */
?>
</ul>
