<?php
/**
 * Single Cart Extend
 */
$settings = $this->get_settings();
?>
    <ul class="cwb-cart-extend-info">
        <?php
        foreach ($settings['extend_pages'] as $content):
            ?>
            <li class="cwb-cart-extend-info-item">
                <a href="<?php echo get_permalink($content["page"]); ?>"
                   title="<?php echo esc_attr($content["page_title"]) ?>" data-target="#cwb-cart-extend-info-<?php echo esc_attr($content["page"])?>">
                    <?php echo esc_html($content["page_title"]) ?>
                </a>
            </li>
        <?php
        endforeach;
        ?>
    </ul>
    <div class="cwb-wrap-content-popup-page">
        <?php
        foreach ($settings['extend_pages'] as $content):
            $post=get_post( $content["page"] )
            ?>
                <div id="cwb-cart-extend-info-<?php echo esc_attr($content["page"])?>" class="cwb-content-popup-page">
                    <?php echo do_shortcode(wp_kses_post($post->post_content)); ?>
                </div>
            <?php
        endforeach; ?>
        <span class="cwb-close-popup-page"><i class="cs-font clever-icon-close"></i></span>
    </div>
    <div class="cwb-close-extend-cart-info"></div>