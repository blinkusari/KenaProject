<?php
/**
 * Teamplte type popup
 */

$doc_types = clever_woo_builder()->documents->get_document_types();

?>
<div class="clever-template-popup">
	<div class="clever-template-popup__overlay"></div>
	<div class="clever-template-popup__content">
		<h3 class="clever-template-popup__heading"><?php
			esc_html_e( 'Add Template', 'clever-woo-builder' );
		?></h3>
		<form class="clever-template-popup__form" method="POST" action="<?php echo esc_url($action); ?>" >
			<div class="clever-template-popup__form-row plain-row">
				<label for="template_type"><?php esc_html_e( 'This template for:', 'clever-woo-builder' ); ?></label>
				<select id="template_type" name="template_type"><?php
					foreach ( $doc_types as $type ) {
						printf(
							'<option value="%1$s">%2$s</option>',
							$type['slug'],
							$type['name']
						);
					}
				?></select>
			</div>
			<div class="clever-template-popup__form-row plain-row">
				<label for="template_name"><?php esc_html_e( 'Template Name:', 'clever-woo-builder' ); ?></label>
				<input type="text" id="template_name" name="template_name" placeholder="<?php esc_html_e( 'Set template name', 'clever-woo-builder' ); ?>">
			</div>
			<h4 class="clever-template-popup__subheading">
				<?php esc_html_e( 'Start from Layout', 'clever-woo-builder' );	?>
			</h4>
			<div class="clever-template-popup__form-row predesigned-row template-<?php echo esc_attr($doc_types['single']['slug']); ?> is-active"><?php
				foreach ( $this->predesigned_single_templates() as $id => $data ) {
					?>
					<div class="clever-template-popup__item">
						<label class="clever-template-popup__label">
							<input type="radio" name="template_single" value="<?php echo esc_attr($id); ?>">
							<img src="<?php echo esc_url($data['thumb']); ?>" alt="">
						</label>
						<span class="clever-template-popup__item--uncheck"><span>×</span></span>
					</div>
					<?php
				}
			?></div>
			<div class="clever-template-popup__form-row predesigned-row template-<?php echo esc_attr($doc_types['archive']['slug']); ?>" style="padding:0 10px 15px;color:red"><?php
                echo esc_html('This feature under development! Some options will not work correctly.','clever-woo-builder')
//				foreach ( $this->predesigned_archive_templates() as $id => $data ) {
//					?>
<!--					<div class="clever-template-popup__item">-->
<!--						<label class="clever-template-popup__label">-->
<!--							<input type="radio" name="template_archive" value="--><?php //echo esc_attr($id); ?><!--">-->
<!--							<img src="--><?php //echo esc_url($data['thumb']); ?><!--" alt="">-->
<!--						</label>-->
<!--						<span class="clever-template-popup__item--uncheck"><span>×</span></span>-->
<!--					</div>-->
<!--					--><?php
//				}
			?></div>
			<div class="clever-template-popup__form-row predesigned-row template-<?php echo esc_attr($doc_types['category']['slug']); ?>" style="padding:0 10px 15px;color:red"><?php
                echo esc_html('This feature under development! Some options will not work correctly.','clever-woo-builder')
//				foreach ( $this->predesigned_category_templates() as $id => $data ) {
//				?>
<!--					<div class="clever-template-popup__item">-->
<!--						<label class="clever-template-popup__label">-->
<!--							<input type="radio" name="template_category" value="--><?php //echo esc_attr($id); ?><!--">-->
<!--							<img src="--><?php //echo esc_url($data['thumb']); ?><!--" alt="">-->
<!--						</label>-->
<!--						<span class="clever-template-popup__item--uncheck"><span>×</span></span>-->
<!--					</div>-->
<!--					--><?php
//				}
			?></div>
			<div class="clever-template-popup__form-row predesigned-row template-<?php echo esc_attr($doc_types['shop']['slug']); ?>" style="padding:0 10px 15px;color:red">
<!--				<div class="predesigned-templates__description">--><?php //esc_html_e( 'For creating this template , you need combine shop template and archive template in Clever Woo Builder settings', 'clever-woo-builder' ); ?><!--</div>-->
				<?php
                echo esc_html('This feature under development! Some options will not work correctly.','clever-woo-builder')
//                foreach ( $this->predesigned_shop_templates() as $id => $data ) {
//				?>
<!--					<div class="clever-template-popup__item">-->
<!--						<label class="clever-template-popup__label">-->
<!--							<input type="radio" name="template_shop" value="--><?php //echo esc_attr($id); ?><!--">-->
<!--							<img src="--><?php //echo esc_url($data['thumb']); ?><!--" alt="">-->
<!--						</label>-->
<!--						<span class="clever-template-popup__item--uncheck"><span>×</span></span>-->
<!--					</div>-->
<!--					--><?php
//				}
			?></div>
			<div class="clever-template-popup__form-actions">
				<button type="submit" id="templates_type_submit" class="button button-primary button-hero"><?php
					esc_html_e( 'Create Template', 'clever-woo-builder' );
				?></button>
			</div>
		</form>
	</div>
</div>