<?php
/**
 * Single add to cart template
 */

$settings      = $this->get_settings();

//Count Down Timer
if( $settings['countdown']){
	add_filter( 'woocommerce_available_variation', 'cwb_filter_woocommerce_available_variation', 10, 3 ); 
	cwb_sale_count_down_simple_html();
}
// Use Ajax Add to Cart
if($settings['add_to_cart_buy_now_options'] == 'ajax'){
	add_action( 'woocommerce_before_add_to_cart_form','use_add_to_cart_ajax', 5 );
}

woocommerce_template_single_add_to_cart();

// Buy Now
if($settings['add_to_cart_buy_now'] && $settings['add_to_cart_buy_now_options'] == 'ajax'){
	buy_now_html($settings['add_to_cart_buy_now_redirect'], $settings['add_to_cart_buy_now_terms_and_conditions'], $settings['add_to_cart_buy_now_label']);
}