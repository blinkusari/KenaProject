<?php
/**
 * Plugin Name: CleverWooBuilder For Elementor
 * Plugin URI:  https://cleveraddon.com/clever-woo-builder/
 * Description: Your perfect asset in creating WooCommerce page templates using loads of special widgets & stylish page layouts
 * Version:     1.0.5
 * Author:      CleverSoft
 * Author URI:  https://cleveraddon.com
 * Text Domain: clever-woo-builder
 * License:     GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Domain Path: /languages
 * WC tested up to: 5.1.0
 * WC requires at least: 5.0
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die();
}

// If class `Clever_Woo_Builder` doesn't exists yet.
if ( ! class_exists( 'Clever_Woo_Builder' ) ) {

	/**
	 * Sets up and initializes the plugin.
	 */
	class Clever_Woo_Builder {

		/**
		 * A reference to an instance of this class.
		 *
		 * @since  1.0.0
		 * @access private
		 * @var    object
		 */
		private static $instance = null;

		/**
		 * Plugin version
		 *
		 * @var string
		 */
		private $version = '1.0.5';

		/**
		 * Holder for base plugin URL
		 *
		 * @since  1.0.0
		 * @access private
		 * @var    string
		 */
		private $plugin_url = null;

		/**
		 * Holder for base plugin path
		 *
		 * @since  1.0.0
		 * @access private
		 * @var    string
		 */
		private $plugin_path = null;

		/**
		 * Plugin properties
		 */
		public $module_loader;

		/**
		 * [$documents description]
		 * @var [type]
		 */
		public $documents;

		/**
		 * [$parser description]
		 * @var [type]
		 */
		public $parser;

		/**
		 * [$macros description]
		 * @var [type]
		 */
		public $macros;

		/**
		 * [$ajax_handlers description]
		 * @var null
		 */
		public $ajax_handlers = null;

		/**
		 * Sets up needed actions/filters for the plugin to initialize.
		 *
		 * @since 1.0.0
		 * @access public
		 * @return void
		 */
		public function __construct() {

			// Load the core functions/classes required by the rest of the plugin.
			add_action( 'after_setup_theme', array( $this, 'module_loader' ), - 20 );

			// Check if Elementor installed and activated.
			if ( ! did_action( 'elementor/loaded' ) ) {
				add_action( 'admin_notices', array( $this, 'admin_notice_missing_main_plugin' ) );
				return;
			}

			// Check that WooCommerce active.
			add_action( 'plugins_loaded', array( $this, 'woocommerce_loaded' ) );

			// Internationalize the text strings used.
			add_action( 'init', array( $this, 'lang' ), - 999 );

			// Load files.
			add_action( 'init', array( $this, 'init' ), - 999 );

			// Clever Dashboard Init
			add_action( 'init', array( $this, 'clever_dashboard_init' ), -999 );

			// Register activation and deactivation hook.
			register_activation_hook( __FILE__, array( $this, 'activation' ) );
			register_deactivation_hook( __FILE__, array( $this, 'deactivation' ) );
		}

		/**
		 * Load plugin framework
		 */
		public function module_loader() {

			require $this->plugin_path( 'includes/modules/loader.php' );

			$this->module_loader = new Clever_Woo_Builder_CX_Loader(
				array(
					$this->plugin_path( 'includes/modules/interface-builder/cherry-x-interface-builder.php' ),
					$this->plugin_path( 'includes/modules/post-meta/cherry-x-post-meta.php' ),
					$this->plugin_path( 'includes/modules/db-updater/cherry-x-db-updater.php' ),
					$this->plugin_path( 'includes/modules/vue-ui/cherry-x-vue-ui.php' ),
					$this->plugin_path( 'includes/modules/clever-dashboard/clever-dashboard.php' ),
				)
			);
		}

		/**
		 * Returns plugin version
		 *
		 * @return string
		 */
		public function get_version() {
			return $this->version;
		}

		/**
		 * Manually init required modules.
		 *
		 * @return void
		 */
		public function init() {

			if ( class_exists( 'WooCommerce' ) ) {

				$this->load_files();

				clever_woo_builder_assets()->init();
				clever_woo_builder_integration()->init();
				clever_woo_builder_integration_woocommerce()->init();
				clever_woo_builder_post_type()->init();

				clever_woo_builder_settings()->init();
				clever_woo_builder_shortocdes()->init();
				clever_woo_builder_shop_settings()->init();
				clever_woo_builder_compatibility()->init();

				$this->documents     = new Clever_Woo_Builder_Documents();
				$this->parser        = new Clever_Woo_Builder_Parser();
				$this->macros        = new Clever_Woo_Builder_Macros();
				$this->ajax_handlers = new Clever_Woo_Builder_Ajax_Handlers();

				if ( is_admin() ) {

					// Init DB upgrader
					require $this->plugin_path( 'includes/class-clever-woo-builder-db-upgrader.php' );

					clever_woo_builder_db_upgrader()->init();
				}
                add_action( 'wp',  [ $this, 'after_theme_setup' ], 999 );

                add_filter( 'woocommerce_product_data_tabs', [ $this, 'advanced_product_tab' ]);
                add_action( 'woocommerce_product_data_panels', [ $this, 'advanced_product_tab_content' ]);
                add_action( 'woocommerce_process_product_meta_simple', [ $this, 'advanced_product_tab_save_content' ]);
                add_action( 'woocommerce_process_product_meta_variable', [ $this, 'advanced_product_tab_save_content' ]);
				//Init Rest Api
				new \Clever_Woo_Builder\Rest_Api();
			}
		}
        function after_theme_setup(){
            remove_theme_support( 'wc-product-gallery-slider' );
        }
		/**
		 * [clever_dashboard_init description]
		 * @return [type] [description]
		 */
		public function clever_dashboard_init() {

			if ( is_admin() ) {

				$clever_dashboard_module_data = $this->module_loader->get_included_module_data( 'clever-dashboard.php' );

				$clever_dashboard = \Clever_Dashboard\Dashboard::get_instance();

				$clever_dashboard->init( array(
					'path'           => $clever_dashboard_module_data['path'],
					'url'            => $clever_dashboard_module_data['url'],
					'cx_ui_instance' => array( $this, 'clever_dashboard_ui_instance_init' ),
					'plugin_data'    => array(
						'slug'         => 'clever-woo-builder',
						'file'         => 'clever-woo-builder/clever-woo-builder.php',
						'version'      => $this->get_version(),
						'plugin_links' => array(
							array(
								'label'  => esc_html__( 'Settings', 'clever-woo-builder' ),
								'url'    => add_query_arg( array( 'page' => 'clever-woo-builder-settings' ), admin_url( 'admin.php' ) ),
								'target' => 'self',
							),
						),
					),
				) );


            }
		}

		/**
		 * [clever_dashboard_ui_instance_init description]
		 * @return [type] [description]
		 */
		public function clever_dashboard_ui_instance_init() {
			$cx_ui_module_data = $this->module_loader->get_included_module_data( 'cherry-x-vue-ui.php' );

			return new CX_Vue_UI( $cx_ui_module_data );
		}

		/**
		 * Check that WooCommerce active
		 */
		function woocommerce_loaded() {

			if ( ! class_exists( 'WooCommerce' ) ) {
				add_action( 'admin_notices', [ $this, 'admin_notice_missing_woocommerce_plugin' ] );

                return;
			}
		}

		/**
		 * [admin_notice_missing_main_plugin description]
		 * @return [type] [description]
		 */
		public function admin_notice_missing_main_plugin() {

			if ( isset( $_GET['activate'] ) ) {
				unset( $_GET['activate'] );
			}

			$elementor_link = sprintf(
				'<a href="%1$s">%2$s</a>',
				admin_url() . 'plugin-install.php?s=elementor&tab=search&type=term',
				'<strong>' . esc_html__( 'Elementor', 'clever-woo-builder' ) . '</strong>'
			);
			$message = sprintf(
				esc_html__( '"%1$s" requires "%2$s" to be installed and activated.', 'clever-woo-builder' ),
				'<strong>' . esc_html__( 'Clever Woo Builder', 'clever-woo-builder' ) . '</strong>',
				$elementor_link
			);
			printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

			if ( ! class_exists( 'WooCommerce' ) ) {
				$woocommerce_link = sprintf(
					'<a href="%1$s">%2$s</a>',
					admin_url() . 'plugin-install.php?s=woocommerce&tab=search&type=term',
					'<strong>' . esc_html__( 'WooCommerce', 'clever-woo-builder' ) . '</strong>'
				);
				$message = sprintf(
					esc_html__( '"%1$s" requires "%2$s" to be installed and activated.', 'clever-woo-builder' ),
					'<strong>' . esc_html__( 'Clever Woo Builder', 'clever-woo-builder' ) . '</strong>',
					$woocommerce_link
				);
				printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
			}
		}
		/**
		 * [admin_notice_missing_main_plugin description]
		 * @return [type] [description]
		 */
		public function admin_notice_missing_woocommerce_plugin() {

			if ( isset( $_GET['activate'] ) ) {
				unset( $_GET['activate'] );
			}

			$woocommerce_link = sprintf(
				'<a href="%1$s">%2$s</a>',
				admin_url() . 'plugin-install.php?s=woocommerce&tab=search&type=term',
				'<strong>' . esc_html__( 'WooCommerce', 'clever-woo-builder' ) . '</strong>'
			);
			$message = sprintf(
				esc_html__( '"%1$s" requires "%2$s" to be installed and activated.', 'clever-woo-builder' ),
				'<strong>' . esc_html__( 'Clever Woo Builder', 'clever-woo-builder' ) . '</strong>',
				$woocommerce_link
			);
			printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
		}

		/**
		 * Check if theme has elementor
		 *
		 * @return boolean
		 */
		public function has_elementor() {
			return defined( 'ELEMENTOR_VERSION' );
		}

		/**
		 * Returns utility instance
		 *
		 * @return object
		 */
		public function utility() {
			$utility = $this->get_core()->modules['cherry-utility'];

			return $utility->utility;
		}

		/**
		 * Load required files.
		 *
		 * @return void
		 */
		public function load_files() {
			require $this->plugin_path( 'includes/class-clever-woo-builder-ajax-handler.php' );
			require $this->plugin_path( 'includes/class-clever-woo-builder-assets.php' );
			require $this->plugin_path( 'includes/class-clever-woo-builder-tools.php' );
			require $this->plugin_path( 'includes/class-clever-woo-builder-post-type.php' );
			require $this->plugin_path( 'includes/class-clever-woo-builder-documents.php' );
			require $this->plugin_path( 'includes/class-clever-woo-builder-parser.php' );
			require $this->plugin_path( 'includes/class-clever-woo-builder-macros.php' );
			require $this->plugin_path( 'includes/class-clever-woo-builder-common-controls.php' );

			require $this->plugin_path( 'includes/integrations/base/class-clever-woo-builder-integration.php' );
			require $this->plugin_path( 'includes/integrations/base/class-clever-woo-builder-integration-woocommerce.php' );

			require $this->plugin_path( 'includes/class-clever-woo-builder-template-functions.php' );
			require $this->plugin_path( 'includes/class-clever-woo-builder-shortcodes.php' );

			require $this->plugin_path( 'includes/settings/class-clever-woo-builder-settings.php' );
			require $this->plugin_path( 'includes/settings/class-clever-woo-builder-shop-settings.php' );

			require $this->plugin_path( 'includes/lib/compatibility/class-clever-woo-builder-compatibility.php' );

			require $this->plugin_path( 'includes/rest-api/rest-api.php' );
			require $this->plugin_path( 'includes/rest-api/endpoints/base.php' );
			require $this->plugin_path( 'includes/rest-api/endpoints/plugin-settings.php' );

			require $this->plugin_path( 'includes/functions/helper.php' );
		}

		/**
		 * Returns path to file or dir inside plugin folder
		 *
		 * @param  string $path Path inside plugin dir.
		 *
		 * @return string
		 */
		public function plugin_path( $path = null ) {

			if ( ! $this->plugin_path ) {
				$this->plugin_path = trailingslashit( plugin_dir_path( __FILE__ ) );
			}
			
			return $this->plugin_path . $path;
		}

		/**
		 * Returns url to file or dir inside plugin folder
		 *
		 * @param  string $path Path inside plugin dir.
		 *
		 * @return string
		 */
		public function plugin_url( $path = null ) {

			if ( ! $this->plugin_url ) {
				$this->plugin_url = trailingslashit( plugin_dir_url( __FILE__ ) );
			}

			return $this->plugin_url . $path;
		}

		/**
		 * Loads the translation files.
		 *
		 * @since 1.0.0
		 * @access public
		 * @return void
		 */
		public function lang() {
			load_plugin_textdomain( 'clever-woo-builder', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
		}

		/**
		 * Get the template path.
		 *
		 * @return string
		 */
		public function template_path() {
			return apply_filters( 'clever-woo-builder/template-path', 'clever-woo-builder/' );
		}

		/**
		 * Returns path to template file.
		 *
		 * @return string|bool
		 */
		public function get_template( $name = null ) {

			$template = locate_template( $this->template_path() . $name );

			if ( ! $template ) {
				$template = $this->plugin_path( 'templates/' . $name );
			}

			if ( file_exists( $template ) ) {
				return $template;
			} else {
				return false;
			}
		}

		/**
		 * Compare WooCommerce version with your version
		 *
		 * @param string $version
		 *
		 * @return bool
		 */
		public static function wc_version_check( $version = '3.6' ) {

			if ( class_exists( 'WooCommerce' ) ) {
				global $woocommerce;

				if ( version_compare( $woocommerce->version, $version, ">=" ) ) {
					return true;
				}
			}

			return false;
		}

		/**
		 * Do some stuff on plugin activation
		 *
		 * @since  1.0.0
		 * @return void
		 */
		public function activation() {}

		/**
		 * Do some stuff on plugin activation
		 *
		 * @since  1.0.0
		 * @return void
		 */
		public function deactivation() {}

		/**
		 * Returns the instance.
		 *
		 * @since  1.0.0
		 * @access public
		 * @return object
		 */
		public static function get_instance() {

			// If the single instance hasn't been set, set it now.
			if ( null == self::$instance ) {
				self::$instance = new self;
			}

			return self::$instance;
		}
		/**
         * Add custom meta tab to woocommerce
		*/
        function advanced_product_tab( $tabs ) {
            $tabs['cwb_adv_tab'] = array(
                'label'  => esc_html__( 'CWB Advanced', 'clever-woo-builder' ),
                'target' => 'cwb_adv_tab',
                'class'  => array( 'cwb_adv_tab_show' ),
            );

            return $tabs;
        }
        /**
         * Contents of zoo advanced product tab.
         */
        function advanced_product_tab_content() {
            global $post;
            // Note the 'id' attribute needs to match the 'target' parameter set above
            ?>
            <div id='cwb_adv_tab' class='panel woocommerce_options_panel'>
                <div class='options_group'><?php
                    woocommerce_wp_text_input( array(
                        'id'                => '_cwb_number_product_on_event',
                        'label'             => __( 'Number product on event', 'clever-woo-builder' ),
                        'desc_tip'          => 'true',
                        'description'       => __( 'Use for display product stock countdown  bar. Product must on sale and Manage stock is enable.', 'clever-woo-builder' ),
                        'type'              => 'number',
                        'custom_attributes' => array(
                            'min'  => '0',
                            'step' => '1',
                        ),
                    ) );
                    ?>
                </div>
            </div>
            <?php
        }
        /**
         * Save contents of zoo advanced product tab.
         */
        function advanced_product_tab_save_content( $post_id ) {
            //Update number_product_on_event
            $number_product_on_event = isset( $_POST['_cwb_number_product_on_event'] ) ?$_POST['_cwb_number_product_on_event']: '0';
            update_post_meta( $post_id, '_cwb_number_product_on_event', $number_product_on_event );

        }
	}
}
if ( ! function_exists( 'clever_woo_builder' ) ) {

	/**
	 * Returns instanse of the plugin class.
	 *
	 * @since  1.0.0
	 * @return object
	 */
	function clever_woo_builder() {
        if( isset($_SERVER['REQUEST_URI']) && preg_match('/\/wp-json\//', $_SERVER['REQUEST_URI']) ) {
            return;
        }
		return Clever_Woo_Builder::get_instance();
	}
}
add_action( 'plugins_loaded', 'clever_woo_builder');
