<?php
/**
 * Class: Clever_Woo_Builder_Single_Get_Order_Time
 * Name: Single Get Order Time
 * Slug: clever-single-get-order-time
 */

namespace Elementor;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;
use Elementor\Core\Schemes\Color;
use Elementor\Widget_Base;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

class Clever_Woo_Builder_Single_Get_Order_Time extends Clever_Woo_Builder_Base {

	public function get_name() {
		return 'clever-single-get-order-time';
	}

	public function get_title() {
		return esc_html__( 'Single Get Order Time', 'clever-woo-builder' );
	}

	public function get_icon() {
		return 'clever-woo-builder-icon-title';
	}

	public function get_clever_help_url() {
		return 'https://cleveraddon.com/knowledge-base/articles/cleverwoobuilder-how-to-create-and-set-a-single-product-page-template/';
	}

	public function get_categories() {
		return array( 'clever-woo-builder' );
	}

	public function show_in_panel() {
		return clever_woo_builder()->documents->is_document_type( 'single' );
	}

	protected function register_controls() {

		$css_scheme = apply_filters(
			'clever-woo-builder/clever-single-get-order-time/css-scheme',
			array(
				'wrap'				=>'.cwb-get-order-notice',
				'icon' 				=> '.cwb-get-order-notice i',
				'order_label' 		=> '.order-label',
				'order_next'		=>'.order-next',
				'end-of-day'		=> '.end-of-day',
				'order_end' 		=> '.order-end',
				'get_order_date' 	=> '.get-order-date',
			)
		);

		$this->start_controls_section(
			'single_get_order_time',
			array(
				'label' => __( 'General', 'clever-woo-builder' ),
			)
		);

		$this->add_control(
			'single_get_order_time_days',
			array(
				'label'        => esc_html__( 'Days', 'clever-woo-builder' ),
				'type'         => Controls_Manager::NUMBER,
				'default'      => '2',
			)
		);
		$this->add_control(
			'single_get_order_time_icon',
			array(
				'label'        	=> esc_html__( 'Icon', 'clever-woo-builder' ),
				'description'	=> esc_html__( 'Need allow "Load Font Awesome 4 Support" in Elementor / Settings / Advanced.', 'clever-woo-builder' ),
                'type' => 'cwbclevericon',
                'default' => 'cs-font clever-icon-clock-3',
			)
		);
		$this->add_control(
			'single_get_order_time_order_next',
			array(
				'label'     => __( 'Order Next', 'clever-woo-builder' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => 'Order in The Next '
			)
		);
		$this->add_control(
			'single_get_order_time_order_end',
			array(
				'label'     => __( 'Order End', 'clever-woo-builder' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => 'to get it by '
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'single_get_order_time_style',
			array(
				'label'      => esc_html__( 'General', 'clever-woo-builder' ),
				'tab'        => Controls_Manager::TAB_STYLE,
				'show_label' => false,
			)
		);

		$this->add_control(
			'single_get_order_time_color',
			array(
				'label'     => esc_html__( 'Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['wrap'] => 'color: {{VALUE}}',
				),
			)
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'single_get_order_time_typo',
				'selector' => '{{WRAPPER}} ' . $css_scheme['wrap'],
			)
		);
        $this->add_control(
            'time_heading',
            array(
                'label'     => esc_html__( 'Time', 'clever-woo-builder' ),
                'type'      => Controls_Manager::HEADING,
                'separator'  => 'after'
            )
        );
        $this->add_control(
            'time_color',
            array(
                'label'     => esc_html__( 'Color', 'clever-woo-builder' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}}  ' . $css_scheme['wrap'].' .end-of-day' => 'color: {{VALUE}}',
                ),
            )
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => 'time_typo',
                'selector' => '{{WRAPPER}} ' . $css_scheme['wrap'].' .end-of-day',
            )
        );$this->add_control(
            'date_heading',
            array(
                'label'     => esc_html__( 'Date', 'clever-woo-builder' ),
                'type'      => Controls_Manager::HEADING,
                'separator'  => 'after'
            )
        );
        $this->add_control(
            'date_color',
            array(
                'label'     => esc_html__( 'Color', 'clever-woo-builder' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}}  ' . $css_scheme['wrap'].' .get-order-date' => 'color: {{VALUE}}',
                ),
            )
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => 'date_typo',
                'selector' => '{{WRAPPER}} ' . $css_scheme['wrap'].' .get-order-date',
                'separator'  => 'after'
            )
        );

		$this->add_responsive_control(
			'single_get_order_time_margin',
			array(
				'label'      => esc_html__( 'Margin', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['wrap'] => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'single_get_order_time_padding',
			array(
				'label'      => esc_html__( 'Padding', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['wrap'] => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'single_get_order_time_alignment',
			array(
				'label'     => esc_html__( 'Alignment', 'clever-woo-builder' ),
				'type'      => Controls_Manager::CHOOSE,
				'default'   => 'left',
				'options'   => array(
					'left'   => array(
						'title' => esc_html__( 'Left', 'clever-woo-builder' ),
						'icon'  => 'eicon-text-align-left',
					),
					'center' => array(
						'title' => esc_html__( 'Center', 'clever-woo-builder' ),
						'icon'  => 'eicon-text-align-center',
					),
					'right'  => array(
						'title' => esc_html__( 'Right', 'clever-woo-builder' ),
						'icon'  => 'eicon-text-align-right',
					),
				),
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['wrap'] => 'text-align: {{VALUE}};',
				),
				'classes'   => 'elementor-control-align',
			)
		);

		$this->add_control('single_get_order_time_icon_title', [
            'label' => esc_html__('Icon', 'clever-woo-builder'),
            'type' => Controls_Manager::HEADING,
            'separator'  => 'after'
        ]);
        $this->add_control(
			'single_get_order_time_icon_color',
			array(
				'label'     => esc_html__( 'Icon Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['icon'] => 'color: {{VALUE}}',
				),
			)
		);
		$this->add_responsive_control(
			'single_get_order_time_icon_size',
			array(
				'label'      => esc_html__( 'Icon Size', 'clever-woo-builder' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array(
					'px',
					'rem',
				),
				'range'      => array(
					'rem'  => array(
						'min' => 0,
						'max' => 10,
					),
					'px' => array(
						'min' => 0,
						'max' => 50,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['icon'] => 'font-size: {{SIZE}}{{UNIT}}',
				),
			)
		);
		$this->add_responsive_control(
			'single_get_order_time_icon_padding',
			array(
				'label'      => esc_html__( 'Padding', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['icon'] => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);


		$this->end_controls_section();

	}

	protected function render() {

		$this->__context = 'render';

		if ( true === $this->__set_editor_product() ) {
			$this->__open_wrap();
			include $this->__get_global_template( 'index' );
			$this->__close_wrap();
			$this->__reset_editor_product();
		}

	}
}
