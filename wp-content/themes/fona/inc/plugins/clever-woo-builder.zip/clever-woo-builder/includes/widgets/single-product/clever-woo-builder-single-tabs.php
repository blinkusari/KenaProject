<?php
/**
 * Class: Clever_Woo_Builder_Single_Tabs
 * Name: Single Tabs
 * Slug: clever-single-tabs
 */

namespace Elementor;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;
use Elementor\Core\Schemes\Color;
use Elementor\Widget_Base;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

class Clever_Woo_Builder_Single_Tabs extends Clever_Woo_Builder_Base {

	public function get_name() {
		return 'clever-single-tabs';
	}

	public function get_title() {
		return esc_html__( 'Single Tabs', 'clever-woo-builder' );
	}

	public function get_icon() {
		return 'clever-woo-builder-icon-single-tabs';
	}

	public function get_script_depends() {
		return array( 'wc-single-product' );
	}

	public function get_categories() {
		return array( 'clever-woo-builder' );
	}

	public function show_in_panel() {
		return clever_woo_builder()->documents->is_document_type( 'single' );
	}

	protected function register_controls() {

		$css_scheme = apply_filters(
			'clever-woo-builder/clever-single-tabs/tabs/css-scheme',
			array(
				'control_wrapper'  	=> '.clever-woo-builder > .clever-single-tabs__wrap ul.wc-tabs',
				'content_wrapper'  	=> '.clever-woo-builder > .clever-single-tabs__wrap .wc-tab',
				'tabs_list_item'   	=> '.clever-woo-builder > .clever-single-tabs__wrap .tabs > li,
										.clever-woo-builder > .clever-single-tabs__wrap .cwb-group-accordion',
				'tabs_item'        	=> '.clever-woo-builder > .clever-single-tabs__wrap .tabs > li,
										.clever-woo-builder > .clever-single-tabs__wrap .cwb-group-accordion > h3.tab-heading',
                'tabs_item_hover'   => '.clever-woo-builder > .clever-single-tabs__wrap .tabs > li:hover,
										.clever-woo-builder > .clever-single-tabs__wrap .cwb-group-accordion:hover > h3.tab-heading',
				'tabs_item_active' 	=> '.clever-woo-builder > .clever-single-tabs__wrap .tabs:not(.off-canvas-tab-control) > li.active,
										.clever-woo-builder > .clever-single-tabs__wrap .cwb-group-accordion.accordion-active > h3.tab-heading',
				'tabs_item_icon' 	=> '.clever-woo-builder > .clever-single-tabs__wrap .cwb-group-accordion .toggle-visible',
				'tabs_item_icon_hover' 	=> '.clever-woo-builder > .clever-single-tabs__wrap .cwb-group-accordion:hover .toggle-visible',
				'tabs_item_icon_active' 	=> '.clever-woo-builder > .clever-single-tabs__wrap .cwb-group-accordion.accordion-active .toggle-visible',
			)
		);

		$this->start_controls_section(
			'single_tabs',
			array(
				'label' => __( 'General', 'clever-woo-builder' ),
			)
		);

		$this->add_control(
			'single_tabs_layout',
			array(
				'label'        => esc_html__( 'Layout', 'clever-woo-builder' ),
				'type'         => Controls_Manager::SELECT,
				'default'      => 'tab',
				'options'      => array(
					'none'  => esc_html__( 'None', 'clever-woo-builder' ),
					'tab'  => esc_html__( 'Tab', 'clever-woo-builder' ),
					'accordion'   => esc_html__( 'Accordion', 'clever-woo-builder' ),
					'off-canvas'   => esc_html__( 'Off Canvas', 'clever-woo-builder' ),
				),
			)
		);

        $this->add_control(
            'single_tabs_off_canvas_position',
            array(
                'label'        => esc_html__( 'Position', 'clever-woo-builder' ),
                'type'         => Controls_Manager::SELECT,
                'default'      => 'right',
                'options'      => array(
                    'right'  => esc_html__( 'Right', 'clever-woo-builder' ),
                    'left'  => esc_html__( 'Left', 'clever-woo-builder' ),
                ),
                'condition'  => array(
                    'single_tabs_layout' => 'off-canvas',
                ),
            )
        );

		$this->add_control(
			'single_tabs_options',
			array(
				'label'        => esc_html__( 'Tabs Options', 'clever-woo-builder' ),
				'type'         => Controls_Manager::SELECT,
				'default'      => 'default',
				'options'      => array(
					'default'  => esc_html__( 'Default', 'clever-woo-builder' ),
					'custom'   => esc_html__( 'Custom', 'clever-woo-builder' ),
				),
			)
		);

		$this->add_control(
			'single_tabs_remove',
			array(
				'label'        => esc_html__( 'Remove Default Tabs', 'clever-woo-builder' ),
				'type'         => Controls_Manager::SELECT2,
				'multiple' => true,
				'default'      => '',
				'label_block' => true,
				'options'      => array(
					'description'  => esc_html__( 'Description', 'clever-woo-builder' ),
					'reviews'   => esc_html__( 'Reviews', 'clever-woo-builder' ),
					'additional_information'   => esc_html__( 'Additional Information', 'clever-woo-builder' ),
				),
				'condition'  => array(
					'single_tabs_options' => 'custom',
				),
			)
		);
        $this->add_control(
            'hide_heading',
            array(
                'label'     => __( 'Hide heading', 'clever-woo-builder' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'true',
                'description'  => esc_html__( 'Heading tab content will remove.', 'clever-woo-builder' ),
                'default' => 'true',
            )
        );

		$this->add_control(
			'single_tabs_position',
			array(
				'label'        => esc_html__( 'Tabs Position', 'clever-woo-builder' ),
				'type'         => Controls_Manager::SELECT,
				'default'      => 'top',
				'prefix_class' => 'elementor-tabs-view-',
				'options'      => array(
					'left'  => esc_html__( 'Left', 'clever-woo-builder' ),
					'top'   => esc_html__( 'Top', 'clever-woo-builder' ),
					'right' => esc_html__( 'Right', 'clever-woo-builder' ),
				),
                'condition'  => array(
                    'single_tabs_layout' => 'tab',
                ),
			)
		);

		$this->add_responsive_control(
			'single_tabs_items_display',
			array(
				'label'      => esc_html__( 'Tabs Items Display', 'clever-woo-builder' ),
				'label_block'=> true,
				'type'       => Controls_Manager::SELECT,
				'default'    => 'row',
				'options'    => array(
					'row'    => esc_html__( 'Inline', 'clever-woo-builder' ),
					'column' => esc_html__( 'Block', 'clever-woo-builder' ),
				),
				'condition'  => array(
					'single_tabs_position' => 'top',
				),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['control_wrapper'] => 'flex-direction: {{VALUE}}',
				),
			)
		);

		$this->add_responsive_control(
			'single_tabs_control_wrapper_width',
			array(
				'label'      => esc_html__( 'Tabs Control Width', 'clever-woo-builder' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array(
					'px',
					'%',
				),
				'range'      => array(
					'%'  => array(
						'min' => 10,
						'max' => 50,
					),
					'px' => array(
						'min' => 100,
						'max' => 500,
					),
				),
				'condition'  => array(
					'single_tabs_position' => array( 'left', 'right' ),
				),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['control_wrapper'] => 'width: {{SIZE}}{{UNIT}}',
					'{{WRAPPER}} ' . $css_scheme['content_wrapper'] => 'width: calc(100% - {{SIZE}}{{UNIT}})',
				),
			)
		);

		$this->add_responsive_control(
			'single_tabs_controls_justify',
			array(
				'label'        => esc_html__( 'Tabs justify', 'clever-woo-builder' ),
				'type'         => Controls_Manager::SELECT,
				'default'      => 'center',
                'options'    => array(
                    'flex-start'    => esc_html__( 'Flex start', 'clever-woo-builder' ),
                    'center'    => esc_html__( 'Center', 'clever-woo-builder' ),
                    'space-between'    => esc_html__( 'Space between', 'clever-woo-builder' ),
                    'space-around'    => esc_html__( 'Space around', 'clever-woo-builder' ),
                    'flex-end'    => esc_html__( 'Flex end', 'clever-woo-builder' ),
                ),
				'condition'  => array(
					'single_tabs_position' => ['top'],
				),
                'selectors'  => array(
                    '{{WRAPPER}} ' . $css_scheme['control_wrapper'] => 'justify-content: {{VALUE}}',
                ),
			)
		);
		$this->add_responsive_control(
			'single_tabs_controls_alignment',
			array(
				'label'        => esc_html__( 'Tab justify', 'clever-woo-builder' ),
				'type'         => Controls_Manager::CHOOSE,
				'default'      => 'left',
				'options'      => array(
					'left'    => array(
						'title' => esc_html__( 'Start', 'clever-woo-builder' ),
						'icon'  => ! is_rtl() ? 'eicon-h-align-left' : 'eicon-h-align-right',
					),
					'center'  => array(
						'title' => esc_html__( 'Center', 'clever-woo-builder' ),
						'icon'  => 'eicon-text-align-center',
					),
					'stretch' => array(
						'title' => esc_html__( 'Stretch', 'clever-woo-builder' ),
						'icon'  => 'eicon-text-align-justify',
					),
					'right'   => array(
						'title' => esc_html__( 'End', 'clever-woo-builder' ),
						'icon'  => ! is_rtl() ? 'eicon-h-align-right' : 'eicon-h-align-left',
					),
				),
				'prefix_class' => 'elementor-tabs-controls-',
				'condition'  => array(
                    'single_tabs_position' => ['left','right'],
				),
			)
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'section_single_tabs_control_style',
			array(
				'label' => esc_html__( 'Tabs Nav', 'clever-woo-builder' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => 'single_tabs_control_background',
				'selector' => '{{WRAPPER}} ' . $css_scheme['control_wrapper'],
			)
		);

		$this->add_responsive_control(
			'single_tabs_control_padding',
			array(
				'label'      => __( 'Padding', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['control_wrapper'] => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'        => 'single_tabs_control_border',
				'label'       => esc_html__( 'Border', 'clever-woo-builder' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} ' . $css_scheme['control_wrapper'],
			)
		);

		$this->add_responsive_control(
			'single_tabs_control_border_radius',
			array(
				'label'      => __( 'Border Radius', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['control_wrapper'] => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_single_tabs_item_style',
			array(
				'label' => esc_html__( 'Tabs Nav Item', 'clever-woo-builder' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'single_tabs_item_width',
			array(
				'label'      => esc_html__( 'Tabs Item Width', 'clever-woo-builder' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array(
					'px',
					'%',
				),
				'range'      => array(
					'%'  => array(
						'min' => 10,
						'max' => 100,
					),
					'px' => array(
						'min' => 100,
						'max' => 500,
					),
				),
				'condition'  => array(
					'single_tabs_position'      => 'top',
					'single_tabs_items_display' => 'column',
				),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['tabs_list_item'] => 'max-width: {{SIZE}}{{UNIT}}',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'single_tabs_item_typography',

				'selector' => '{{WRAPPER}} ' . $css_scheme['tabs_item'],
			)
		);

		$this->add_responsive_control(
			'single_tabs_item_alignment',
			array(
				'label'     => esc_html__( 'Item Text Alignment', 'clever-woo-builder' ),
				'type'      => Controls_Manager::CHOOSE,
				'default'   => 'left',
				'options'   => array(
					'left'   => array(
						'title' => esc_html__( 'Left', 'clever-woo-builder' ),
						'icon'  => 'eicon-text-align-left',
					),
					'center' => array(
						'title' => esc_html__( 'Center', 'clever-woo-builder' ),
						'icon'  => 'eicon-text-align-center',
					),
					'right'  => array(
						'title' => esc_html__( 'Right', 'clever-woo-builder' ),
						'icon'  => 'eicon-text-align-right',
					),
				),
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['tabs_item'] => 'text-align: {{VALUE}};',
				),
				'classes'   => 'elementor-control-align',
                'separator'=>'after',
			)
		);

		$this->add_responsive_control(
			'single_tabs_item_padding',
			array(
				'label'      => __( 'Padding', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['tabs_item'] => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'single_tabs_item_margin',
			array(
				'label'      => __( 'Margin', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['tabs_item'] => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'        => 'single_tabs_item_border',
				'label'       => esc_html__( 'Border', 'clever-woo-builder' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} ' . $css_scheme['tabs_item'],
			)
		);

		$this->add_responsive_control(
			'single_tabs_item_border_radius',
			array(
				'label'      => __( 'Border Radius', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['tabs_item'] => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
        $this->add_control(
            'single_tabs_item_heading_styles',
            array(
                'label'      => __( 'Color & Background', 'clever-woo-builder' ),
                'type'       => Controls_Manager::HEADING,
                'separator'=>'before',
            )
        );
		$this->start_controls_tabs( 'single_tabs_item_styles' );

		$this->start_controls_tab(
			'single_tabs_item_normal',
			array(
				'label' => esc_html__( 'Normal', 'clever-woo-builder' ),
			)
		);

		$this->add_control(
			'single_tabs_item_color_normal',
			array(
				'label'     => esc_html__( 'Text Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['tabs_item'] => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_control(
			'single_tabs_item_background_normal',
			array(
				'label'     => esc_html__( 'Background', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['tabs_item'] => 'background-color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'single_tabs_item_box_shadow_normal',
				'selector' => '{{WRAPPER}} ' . $css_scheme['tabs_item'],
			)
		);
		$this->add_control(
			'single_tabs_item_icon_color_normal',
			array(
				'label'     => esc_html__( 'Icon Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['tabs_item_icon'] => 'color: {{VALUE}}',
				),
			)
		);
		$this->add_responsive_control(
			'single_tabs_item_icon_size',
			array(
				'label'      => esc_html__( 'Icon Size', 'clever-woo-builder' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array(
					'px',
					'rem',
				),
				'range'      => array(
					'rem'  => array(
						'min' => 0,
						'max' => 10,
					),
					'px' => array(
						'min' => 0,
						'max' => 50,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['tabs_item_icon'] => 'font-size: {{SIZE}}{{UNIT}}',
				),
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'single_tabs_item_hover',
			array(
				'label' => esc_html__( 'Hover', 'clever-woo-builder' ),
			)
		);

		$this->add_control(
			'single_tabs_item_color_hover',
			array(
				'label'     => esc_html__( 'Text Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['tabs_item_hover'] => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_control(
			'single_tabs_item_background_hover',
			array(
				'label'     => esc_html__( 'Background', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' .$css_scheme['tabs_item_hover'] => 'background-color: {{VALUE}}',
				),
			)
		);

		$this->add_control(
			'single_tabs_item_border_color_hover',
			array(
				'label'     => esc_html__( 'Border Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' .$css_scheme['tabs_item_hover'] => 'border-color: {{VALUE}}',
				),
			)
		);

		$this->add_control(
			'single_tabs_item_decoration_hover',
			array(
				'label'     => esc_html__( 'Text Decoration', 'clever-woo-builder' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'none',
				'options'   => array(
					'none'         => esc_html__( 'None', 'clever-woo-builder' ),
					'line-through' => esc_html__( 'Line Through', 'clever-woo-builder' ),
					'underline'    => esc_html__( 'Underline', 'clever-woo-builder' ),
					'overline'     => esc_html__( 'Overline', 'clever-woo-builder' ),
				),
				'selectors' => array(
					'{{WRAPPER}} '.$css_scheme['tabs_item_hover'] => 'text-decoration: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'single_tabs_item_box_shadow_hover',
				'selector' => '{{WRAPPER}} ' .$css_scheme['tabs_item_hover'],
			)
		);
		$this->add_control(
			'single_tabs_item_icon_color_hover',
			array(
				'label'     => esc_html__( 'Icon Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' .$css_scheme['tabs_item_icon_hover'] => 'color: {{VALUE}}',
				),
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'single_tabs_item_active',
			array(
				'label' => esc_html__( 'Active', 'clever-woo-builder' ),
			)
		);

		$this->add_control(
			'single_tabs_item_color_active',
			array(
				'label'     => esc_html__( 'Text Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['tabs_item_active'] => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_control(
			'single_tabs_item_background_active',
			array(
				'label'     => esc_html__( 'Background', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['tabs_item_active'] => 'background-color: {{VALUE}}',
				),
			)
		);

		$this->add_control(
			'single_tabs_item_border_color_active',
			array(
				'label'     => esc_html__( 'Border Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['tabs_item_active'] => 'border-color: {{VALUE}}',
				),
			)
		);

		$this->add_control(
			'single_tabs_item_decoration_active',
			array(
				'label'     => esc_html__( 'Text Decoration', 'clever-woo-builder' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'none',
				'options'   => array(
					'none'         => esc_html__( 'None', 'clever-woo-builder' ),
					'line-through' => esc_html__( 'Line Through', 'clever-woo-builder' ),
					'underline'    => esc_html__( 'Underline', 'clever-woo-builder' ),
					'overline'     => esc_html__( 'Overline', 'clever-woo-builder' ),
				),
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['tabs_item_active'] => 'text-decoration: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'single_tabs_item_box_shadow_active',
				'selector' => '{{WRAPPER}} ' . $css_scheme['tabs_item_active'],
			)
		);
		$this->add_control(
			'single_tabs_item_icon_color_active',
			array(
				'label'     => esc_html__( 'Icon Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['tabs_item_icon_active'] => 'color: {{VALUE}}',
				),
			)
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();

		$this->start_controls_section(
			'section_single_tabs_content_style',
			array(
				'label' => esc_html__( 'Tabs Content', 'clever-woo-builder' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);
        $this->add_responsive_control(
            'section_single_tabs_content_width',
            array(
                'label'      => esc_html__( 'Max Width', 'clever-woo-builder' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => array(
                    'px',
                    '%',
                ),
                'range'      => array(
                    '%'  => array(
                        'min' => 10,
                        'max' => 50,
                    ),
                    'px' => array(
                        'min' => 100,
                        'max' => 2000,
                    ),
                ),
                'selectors'  => array(
                    '{{WRAPPER}} ' . $css_scheme['content_wrapper'] => 'max-width: {{SIZE}}{{UNIT}};margin-left:auto;margin-right:auto',
                ),
            )
        );
        $this->add_control(
            'single_tabs_content_heading_head',
            array(
                'label'      => __( 'Heading', 'clever-woo-builder' ),
                'type'       => Controls_Manager::HEADING,
                'separator'=>'before',
                'condition'  => array(
                    'single_tabs_layout' => 'off-canvas',
                ),
            )
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => 'single_tabs_content_heading_typo',
                'selector' => '{{WRAPPER}} .wrap-off-canvas-tab .tab-heading',
            )
        );

        $this->add_control(
            'single_tabs_content_heading_color',
            array(
                'label'     => esc_html__( 'Heading Color', 'clever-woo-builder' ),
                'type'      => Controls_Manager::COLOR,
                'condition'  => array(
                    'single_tabs_layout' => 'off-canvas',
                ),
                'selectors' => array(
                    '{{WRAPPER}} .wrap-off-canvas-tab .tab-heading' => 'color: {{VALUE}}',
                ),
            )
        );
        $this->add_responsive_control(
            'single_tabs_content_heading_padding',
            array(
                'label'      => __( 'Heading Padding', 'clever-woo-builder' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'condition'  => array(
                    'single_tabs_layout' => 'off-canvas',
                ),
                'selectors'  => array(
                    '{{WRAPPER}} .wrap-off-canvas-tab .tab-heading' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
                'separator'=>'after',
            )
        );
        $this->add_responsive_control(
            'single_tabs_content_heading_margin',
            array(
                'label'      => __( 'Heading Margin', 'clever-woo-builder' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'condition'  => array(
                    'single_tabs_layout' => 'off-canvas',
                ),
                'selectors'  => array(
                    '{{WRAPPER}} .wrap-off-canvas-tab .tab-heading' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
                'separator'=>'after',
            )
        );
		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => 'single_tabs_content_background',
				'selector' => '{{WRAPPER}} ' . $css_scheme['content_wrapper'],
			)
		);

		$this->add_responsive_control(
			'single_tabs_content_padding',
			array(
				'label'      => __( 'Padding', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['content_wrapper'] => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .wrap-off-canvas-tab-content' => 'padding:0 {{RIGHT}}{{UNIT}} 0 {{LEFT}}{{UNIT}};margin:0 -{{RIGHT}}{{UNIT}} 0 -{{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'        => 'single_tabs_content_border',
				'label'       => esc_html__( 'Border', 'clever-woo-builder' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} ' . $css_scheme['content_wrapper'],
			)
		);

		$this->add_responsive_control(
			'single_tabs_content_radius',
			array(
				'label'      => __( 'Border Radius', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['content_wrapper'] => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();

	}

	protected function render() {

		$this->__context = 'render';

        $settings = apply_filters( 'clever-woo-builder/clever-single-tabs/settings', $this->get_settings(), $this );
        if($settings['hide_heading']=='true'){
            add_filter( 'woocommerce_product_description_heading', '__return_null' );
            add_filter( 'woocommerce_product_additional_information_heading', '__return_null' );
        }
		if ( true === $this->__set_editor_product() ) {
			$this->__open_wrap();

			$this->fix_comments_template();

			include $this->__get_global_template( 'index' );
			$this->__close_wrap();
			$this->__reset_editor_product();
		}

	}

	public function fix_comments_template() {

		if ( ! clever_woo_builder_integration()->in_elementor() && ! wp_doing_ajax() ) {
			return;
		}

		add_filter( 'comments_template', array( $this, 'comments_template_loader' ) );

	}

	/**
	 * Load comments template
	 *
	 * @return string
	 */
	public function comments_template_loader( $template ) {

		$check_dirs = array(
			trailingslashit( get_stylesheet_directory() ) . WC()->template_path(),
			trailingslashit( get_template_directory() ) . WC()->template_path(),
			trailingslashit( get_stylesheet_directory() ),
			trailingslashit( get_template_directory() ),
			trailingslashit( WC()->plugin_path() ) . 'templates/',
		);

		if ( WC_TEMPLATE_DEBUG_MODE ) {
			$check_dirs = array( array_pop( $check_dirs ) );
		}

		foreach ( $check_dirs as $dir ) {
			if ( file_exists( trailingslashit( $dir ) . 'single-product-reviews.php' ) ) {
				return trailingslashit( $dir ) . 'single-product-reviews.php';
			}
		}
	}

}
