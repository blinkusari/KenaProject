<?php
/**
 * Ocean WP integration
 */

add_action( 'elementor/page_templates/canvas/before_content', 'clever_woo_oceanwp_open_site_main_wrap', -999 );
add_action( 'clever-woo-builder/blank-page/before-content', 'clever_woo_oceanwp_open_site_main_wrap', -999 );
add_action( 'elementor/page_templates/header-footer/before_content', 'clever_woo_oceanwp_open_site_main_wrap', -999 );
add_action( 'clever-woo-builder/full-width-page/before-content', 'clever_woo_oceanwp_open_site_main_wrap', -999 );

add_action( 'elementor/page_templates/canvas/after_content', 'clever_woo_oceanwp_close_site_main_wrap', 999 );
add_action( 'clever-woo-builder/blank-page/after_content', 'clever_woo_oceanwp_close_site_main_wrap', 999 );
add_action( 'elementor/page_templates/header-footer/after_content', 'clever_woo_oceanwp_close_site_main_wrap', 999 );
add_action( 'clever-woo-builder/full-width-page/after_content', 'clever_woo_oceanwp_close_site_main_wrap', 999 );

add_action( 'elementor/widgets/widgets_registered', 'clever_woo_oceanwp_fix_wc_hooks' );

add_action( 'wp_enqueue_scripts', 'clever_woo_oceanwp_enqueue_styles' );

add_filter( 'ocean_post_layout_class', 'clever_woo_oceanwp_display_sidebar' );

function clever_woo_oceanwp_display_sidebar( $class ){

	if ( get_post_type() === 'clever-woo-builder' ){
		$class = 'full-width';
	}

	return $class;

}

/**
 * Fix WooCommerce hooks for oceanwp
 *
 * @return [type] [description]
 */
function clever_woo_oceanwp_fix_wc_hooks() {
	remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10 );
	remove_action( 'woocommerce_shop_loop_item_title', 'woocommerce_template_loop_product_title', 10 );
	remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10 );
	remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10 );
}

/**
 * Open .site-main wrapper for products
 * @return [type] [description]
 */
function clever_woo_oceanwp_open_site_main_wrap() {
	if ( ! is_singular( array( clever_woo_builder_post_type()->slug(), 'product' ) ) ) {
		return;
	}

	echo '<div class="site-main">';
}

/**
 * Close .site-main wrapper for products
 * @return [type] [description]
 */
function clever_woo_oceanwp_close_site_main_wrap() {

	if ( ! is_singular( array( clever_woo_builder_post_type()->slug(), 'product' ) ) ) {
		return;
	}

	echo '</div>';
}

/**
 * Enqueue Ocean WP integration stylesheets.
 *
 * @since 1.0.0
 * @access public
 * @return void
 */
function clever_woo_oceanwp_enqueue_styles() {
	wp_enqueue_style(
		'clever-woo-builder-oceanwp',
		clever_woo_builder()->plugin_url( 'includes/integrations/themes/oceanwp/assets/css/style.css' ),
		false,
		clever_woo_builder()->get_version()
	);
}