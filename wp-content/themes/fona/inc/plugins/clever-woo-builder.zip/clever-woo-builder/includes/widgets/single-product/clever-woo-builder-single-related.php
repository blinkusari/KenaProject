<?php
/**
 * Class: Clever_Woo_Builder_Single_Related
 * Name: Single Related Products
 * Slug: clever-single-related
 */

namespace Elementor;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;
use Elementor\Core\Schemes\Color;
use Elementor\Widget_Base;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

class Clever_Woo_Builder_Single_Related extends Clever_Woo_Builder_Base {

	public function get_name() {
		return 'clever-single-related';
	}

	public function get_title() {
		return esc_html__( 'Single Related Products', 'clever-woo-builder' );
	}

	public function get_icon() {
		return 'clever-woo-builder-icon-single-related';
	}

	public function get_script_depends() {
		return array();
	}

	public function get_clever_help_url() {
		return 'https://cleveraddon.com/knowledge-base/articles/cleverwoobuilder-how-to-create-and-set-a-single-product-page-template/';
	}

	public function get_categories() {
		return array( 'clever-woo-builder' );
	}

	public function show_in_panel() {
		return clever_woo_builder()->documents->is_document_type( 'single' );
	}

	protected function register_controls() {

		$css_scheme = apply_filters(
			'clever-woo-builder/clever-single-related/css-scheme',
			array(
				'title' => '.clever-woo-builder .related.products > h2'
			)
		);
        $this->start_controls_section(
            'section_general',
            array(
                'label' => esc_html__('General', 'clever-woo-builder'),
            )
        );

        $this->add_control(
            'layout',
            array(
                'label' => __('Layout', 'clever-woo-builder'),
                'type' => Controls_Manager::SELECT,
                'default' => 'grid',
                'options' => array(
                    'grid' => esc_html__('Grid', 'clever-woo-builder'),
                    'carousel' => esc_html__('Carousel', 'clever-woo-builder'),
                ),

            )
        );
        $this->add_responsive_control('product_number', [
            'label' => esc_html__('Product number', 'clever-woo-builder'),
            'type' => Controls_Manager::NUMBER,
            'default' => '4',
            'description' => esc_html__('Number products display', 'clever-woo-builder'),
        ]);
        $this->add_responsive_control('cols', [
            'label' => esc_html__('Columns', 'clever-woo-builder'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 1,
                    'max' => 6,
                ]
            ],
            'desktop_default' => [
                'size' => 4,
                'unit' => 'px',
            ],
            'tablet_default' => [
                'size' => 2,
                'unit' => 'px',
            ],
            'mobile_default' => [
                'size' => 1,
                'unit' => 'px',
            ],
            'devices' => ['desktop', 'tablet', 'mobile'],
            'selectors' => [
                '{{WRAPPER}} .related .products.grid-layout .product' => 'width:calc(100%/{{SIZE}});'
            ],
        ]);
        $this->add_responsive_control('gutter', [
            'label' => esc_html__('Gutter', 'clever-woo-builder'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 100,
                ]
            ],
            'desktop_default' => [
                'size' => 30,
                'unit' => 'px',
            ],
            'tablet_default' => [
                'size' => 30,
                'unit' => 'px',
            ],
            'mobile_default' => [
                'size' => 30,
                'unit' => 'px',
            ],
            'devices' => ['desktop', 'tablet', 'mobile'],
            'selectors' => [
                '{{WRAPPER}} .related .products' => 'margin-left:calc(-{{SIZE}}{{UNIT}}/2);margin-right:calc(-{{SIZE}}{{UNIT}}/2);width:calc(100% + {{SIZE}}{{UNIT}})',
                '{{WRAPPER}} .related .products .product' => 'padding-left:calc({{SIZE}}{{UNIT}}/2);padding-right:calc({{SIZE}}{{UNIT}}/2);'
            ],
        ]);

        $this->add_control('dots', [
            'label' => esc_html__('Show pagination', 'clever-woo-builder'),
            'type' => Controls_Manager::SWITCHER,
            'return_value' => 'true',
            'default' => 'true',
            'condition' => [
                'layout' => ['carousel']
            ],
        ]);
        $this->add_control('arrows', [
            'label' => esc_html__('Show navigation', 'clever-woo-builder'),
            'type' => Controls_Manager::SWITCHER,
            'description' => esc_html__('Show next and previous button.', 'clever-woo-builder'),
            'return_value' => 'true',
            'default' => 'true', 'condition' => [
                'layout' => ['carousel']
            ],
        ]);
        $this->add_control('arrow_left', [
            'label' => esc_html__('Arrow Previous', 'clever-woo-builder'),
            'type' => 'cwbclevericon',
            'default' => 'cs-font clever-icon-prev',
            'condition' => [
                'arrows' => 'true',
                'layout' => ['carousel']
            ],
        ]);
        $this->add_control('arrow_right', [
            'label' => esc_html__('Arrow Next', 'clever-woo-builder'),
            'type' => 'cwbclevericon',
            'default' => 'cs-font clever-icon-next',
            'condition' => [
                'arrows' => 'true',
                'layout' => ['carousel']
            ],
        ]);
        $this->end_controls_section();
		$this->start_controls_section(
			'section_single_related_style',
			array(
				'label' => esc_html__( 'Title', 'clever-woo-builder' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'single_related_title_color',
			array(
				'label'     => esc_html__( 'Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['title'] => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'single_related_title_typography',
				'selector' => '{{WRAPPER}} ' . $css_scheme['title'],
			)
		);

		$this->add_responsive_control(
			'single_related_title_margin',
			array(
				'label'      => __( 'Margin', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['title'] => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'single_related_title_alignment',
			array(
				'label'     => esc_html__( 'Alignment', 'clever-woo-builder' ),
				'type'      => Controls_Manager::CHOOSE,
				'default'   => 'center',
				'options'   => array(
					'left'   => array(
						'title' => esc_html__( 'Left', 'clever-woo-builder' ),
						'icon'  => 'eicon-text-align-left',
					),
					'center' => array(
						'title' => esc_html__( 'Center', 'clever-woo-builder' ),
						'icon'  => 'eicon-text-align-center',
					),
					'right'  => array(
						'title' => esc_html__( 'Right', 'clever-woo-builder' ),
						'icon'  => 'eicon-text-align-right',
					),
				),
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['title'] => 'text-align: {{VALUE}};',
				),
				'classes'   => 'elementor-control-align',
			)
		);

		$this->end_controls_section();
        $this->start_controls_section(
            'section_main_pagination_style',
            array(
                'label' => esc_html__( 'Pagination', 'clever-woo-builder' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'dots' => 'true',
                    'layout' => ['carousel']
                ],
            )
        );
        $this->add_responsive_control('dots_size',[
            'label'         => esc_html__('Size', 'clever-woo-builder' ),
            'type'          => Controls_Manager::SLIDER,
            'range' => [
                'px' =>[
                    'min' => 0,
                    'max' => 100,
                ]
            ],
            'desktop_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'tablet_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'mobile_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'selectors' => [
                '{{WRAPPER}} .related .products .slick-dots button' => 'width:{{SIZE}}{{UNIT}};height:{{SIZE}}{{UNIT}}',
            ],
        ]);
        $this->add_responsive_control('dots_space',[
            'label'         => esc_html__('Space', 'clever-woo-builder' ),
            'type'          => Controls_Manager::SLIDER,
            'range' => [
                'px' =>[
                    'min' => 0,
                    'max' => 100,
                ]
            ],
            'desktop_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'tablet_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'mobile_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'description' => esc_html__('Space between each item.', 'clever-woo-builder'),
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'selectors' => [
                '{{WRAPPER}} .related .products .slick-dots li' => 'margin-right:{{SIZE}}{{UNIT}};',
            ],
        ]);
        $this->start_controls_tabs( 'dots_background_tabs' );

        $this->start_controls_tab( 'dots_normal', [ 'label' => esc_html__('Normal', 'cafe-lite' ) ] );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'     => 'dots_border',
                'selector' => '{{WRAPPER}} .related .products .slick-dots button',
            )
        );
        $this->add_control(
            'dots_bg_color',
            array(
                'label' => esc_html__( 'Background Color', 'clever-woo-builder' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .related .products .slick-dots button'  => 'background-color: {{VALUE}}',
                ),
            )
        );
        $this->end_controls_tab();
        $this->start_controls_tab( 'dots_active', [ 'label' => esc_html__('Hover/Active', 'cafe-lite' ) ] );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'     => 'dots_active_border',
                'selector' => '{{WRAPPER}} .related .products .slick-dots button:hover, {{WRAPPER}} .related .products .slick-dots .slick-active button',
            )
        );
        $this->add_control(
            'dots_active_bg_color',
            array(
                'label' => esc_html__( 'Background Color', 'clever-woo-builder' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .related .products .slick-dots button:hover, {{WRAPPER}} .related .products .slick-dots .slick-active button'  => 'background-color: {{VALUE}}',
                ),
            )
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->add_responsive_control(
            'dots_border_radius',
            array(
                'label'      => esc_html__( 'Border Radius', 'clever-woo-builder' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'separator'   => 'before',
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .related .products .slick-dots button'=> 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'section_main_nav_style',
            array(
                'label' => esc_html__( 'Navigation', 'clever-woo-builder' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'arrows' => 'true',
                    'layout' => ['carousel']
                ],
            )
        );
        $this->add_responsive_control('nav_size',[
            'label'         => esc_html__('Size', 'clever-woo-builder' ),
            'type'          => Controls_Manager::SLIDER,
            'range' => [
                'px' =>[
                    'min' => 0,
                    'max' => 200,
                ]
            ],
            'desktop_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'tablet_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'mobile_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'selectors' => [
                '{{WRAPPER}} .related .products .cwb-carousel-btn' => 'width:{{SIZE}}{{UNIT}};height:{{SIZE}}{{UNIT}}',
            ],
        ]);

        $this->add_responsive_control('nav_icon_size',[
            'label'         => esc_html__('Icon Size', 'clever-woo-builder' ),
            'type'          => Controls_Manager::SLIDER,
            'range' => [
                'px' =>[
                    'min' => 0,
                    'max' => 100,
                ]
            ],
            'desktop_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'tablet_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'mobile_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'condition' => [
                'layout' => ['vertical','horizontal']
            ],
            'description' => esc_html__('Space between each item.', 'clever-woo-builder'),
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'selectors' => [
                '{{WRAPPER}} .related .products .cwb-carousel-btn' => 'font-size:{{SIZE}}{{UNIT}};',
            ],
        ]);
        $this->start_controls_tabs( 'nav_background_tabs' );

        $this->start_controls_tab( 'nav_normal', [ 'label' => esc_html__('Normal', 'cafe-lite' ) ] );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'     => 'nav_border',
                'selector' => '{{WRAPPER}} .related .products .cwb-carousel-btn',
            )
        );
        $this->add_control(
            'nav_color',
            array(
                'label' => esc_html__( 'Color', 'clever-woo-builder' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .related .products .cwb-carousel-btn'  => 'color: {{VALUE}}',
                ),
            )
        );
        $this->add_control(
            'nav_bg_color',
            array(
                'label' => esc_html__( 'Background Color', 'clever-woo-builder' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .related .products .cwb-carousel-btn'  => 'background-color: {{VALUE}}',
                ),
            )
        );
        $this->end_controls_tab();
        $this->start_controls_tab( 'nav_active', [ 'label' => esc_html__('Hover/Active', 'cafe-lite' ) ] );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'     => 'nav_active_border',
                'selector' => '{{WRAPPER}} .related .products .cwb-carousel-btn:hover',
            )
        );
        $this->add_control(
            'nav_active_color',
            array(
                'label' => esc_html__( 'Color', 'clever-woo-builder' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .related .products .cwb-carousel-btn:hover'  => 'color: {{VALUE}}',
                ),
            )
        );
        $this->add_control(
            'nav_active_bg_color',
            array(
                'label' => esc_html__( 'Background Color', 'clever-woo-builder' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .related .products .cwb-carousel-btn:hover'  => 'background-color: {{VALUE}}',
                ),
            )
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->add_responsive_control(
            'nav_border_radius',
            array(
                'label'      => esc_html__( 'Border Radius', 'clever-woo-builder' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'separator'   => 'before',
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .related .cwb-carousel-btn'=> 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );

        $this->end_controls_section();
	}

	protected function render() {

		$this->__context = 'render';

		if ( true === $this->__set_editor_product() ) {
			$this->__open_wrap();
			remove_filter( 'woocommerce_product_loop_start', 'woocommerce_maybe_show_product_subcategories' );
            add_filter( 'woocommerce_product_loop_start', array( $this, 'related_products_loop_start' ));
            add_filter( 'woocommerce_output_related_products_args', array( $this, 'product_number' ));
			include $this->__get_global_template( 'index' );
			$this->__close_wrap();
			$this->__reset_editor_product();
		}

	}
	function product_number($args){
        $settings = apply_filters( 'clever-woo-builder/clever-woo-single-add-to-cart/settings', $this->get_settings(), $this );
        $args['posts_per_page'] = $settings['product_number'];
        return $args;
    }
	function related_products_loop_start(){
        $settings = apply_filters( 'clever-woo-builder/clever-woo-single-add-to-cart/settings', $this->get_settings(), $this );
        $slider_json_config = '{
        "slidesToShow": "' . $settings['cols']['size'] . '",
        "slidesToShow_table": "' . $settings['cols_tablet']['size'] . '",
        "slidesToShow_mobile": "' . $settings['cols_mobile']['size'] . '",
        "arrows":"' . $settings['arrows'] . '",
        "arrow_left":"' . $settings['arrow_left'] . '",
        "arrow_right":"' . $settings['arrow_right'] . '",        
        "dots":"' . $settings['dots'] . '"
        }';
        $css_class= "products";
        if(function_exists('zoo_product_hover_effect')){
            $css_class.=" hover-effect-" . zoo_product_hover_effect();
        }
        if ( $settings['layout'] == "grid" ) {
            $css_class .= " grid-layout";
            return '<ul class="' . esc_attr( $css_class ) . '" data-cwb-config=\'' . esc_attr( $slider_json_config ) . '\'>';
        } else {
            wp_enqueue_style( 'slick' );
            wp_enqueue_script( 'slick' );
            $css_class .= " carousel-layout carousel cwb-carousel";
            return '<ul class="' . esc_attr( $css_class ) . '" data-cwb-config=\'' . esc_attr( $slider_json_config ) . '\'>';
        }
    }
}
