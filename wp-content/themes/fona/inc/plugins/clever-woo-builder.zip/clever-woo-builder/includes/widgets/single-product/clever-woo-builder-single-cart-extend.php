<?php
/**
 * Class: Clever_Woo_Builder_Single_Cart_Extend
 * Name: Single Cart Extend
 * Slug: clever-single-cart-extend
 */

namespace Elementor;

use Elementor\Core\Schemes\Color;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

class Clever_Woo_Builder_Single_Cart_Extend extends Clever_Woo_Builder_Base {

	public function get_name() {
		return 'clever-single-cart-extend';
	}

	public function get_title() {
		return esc_html__( 'Single Cart Extend', 'clever-woo-builder' );
	}

	public function get_icon() {
		return 'clever-woo-builder-icon-excerpt';
	}

	public function get_script_depends() {
		return array();
	}

	public function get_categories() {
		return array( 'clever-woo-builder' );
	}

	public function show_in_panel() {
		return clever_woo_builder()->documents->is_document_type( 'single' );
	}

	protected function register_controls() {

        $repeater = new \Elementor\Repeater();
        $repeater->add_control(
            'page_title',
            array(
                'type'        => 'text',
                'label'       => esc_html__( 'Title', 'clever-woo-builder' ),
                'default'     => esc_html__( 'Size Guide', 'clever-woo-builder' ),
            )
        );
        $repeater->add_control('page', [
            'label' => esc_html__('Page', 'clever-woo-builder'),
            'description' => esc_html__('', 'clever-woo-builder'),
            'type' => Controls_Manager::SELECT,
            'default' => '',
            'options' => $this->get_list_posts('page'),
        ]);
		$this->start_controls_section(
			'section_content',
			array(
				'label'      => esc_html__( 'Content', 'clever-woo-builder' ),
				'tab'        => Controls_Manager::TAB_CONTENT,
				'show_label' => false,
			)
		);
        $this->add_control('extend_pages', [
            'label' => esc_html__('Extend pages', 'clever-woo-builder'),
            'type' => Controls_Manager::REPEATER,
            'fields' => $repeater->get_controls(),
            'title_field' => '{{{ page_title }}}',
            'separator' => 'after',
        ]);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style',
			array(
				'label'      => esc_html__( 'General style', 'clever-woo-builder' ),
				'tab'        => Controls_Manager::TAB_STYLE,
				'show_label' => false,
			)
		);
        $this->add_responsive_control('max_width', [
            'label' => esc_html__('Popup width', 'clever-woo-builder'),
            'type' => Controls_Manager::SLIDER,
            'size_units' => array(
                'px',
                '%',
                'vw',
            ),
            'range'      => array(
                '%'  => array(
                    'min' => 10,
                    'max' => 100,
                ),
                'px' => array(
                    'min' => 100,
                    'max' => 1920,
                ),'vw' => array(
                    'min' => 10,
                    'max' => 100,
                ),
            ),
            'devices' => ['desktop', 'tablet', 'mobile'],
            'desktop_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'tablet_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'mobile_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'selectors'  => array(
                '{{WRAPPER}} .cwb-wrap-content-popup-page' => 'width: {{SIZE}}{{UNIT}};',
            ),
        ]);
        $this->add_responsive_control(
            'alignment',
            array(
                'label'   => esc_html__( 'Alignment', 'clever-woo-builder' ),
                'type'    => Controls_Manager::CHOOSE,
                'options' => array(
                    'left' => array(
                        'title' => esc_html__( 'Left', 'clever-woo-builder' ),
                        'icon'  => 'fa fa-align-left',
                    ),
                    'center' => array(
                        'title' => esc_html__( 'Center', 'clever-woo-builder' ),
                        'icon'  => 'fa fa-align-center',
                    ),
                    'right' => array(
                        'title' => esc_html__( 'Right', 'clever-woo-builder' ),
                        'icon'  => 'fa fa-align-right',
                    ),
                ),
                'selectors'  => array(
                    '{{WRAPPER}} .cwb-cart-extend-info' => 'text-align: {{VALUE}};',
                ),
            )
        );
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'typography',
				'selector' => '{{WRAPPER}} .cwb-cart-extend-info a',
			)
		);
        $this->add_control('color', [
            'label' => esc_html__('Color', 'clever-woo-builder'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .cwb-cart-extend-info a' => 'color: {{COLOR}}',
            ],
        ]);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'        => 'border',
				'label'       => esc_html__( 'Border', 'clever-woo-builder' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .cwb-cart-extend-info-item a',
			)
		);
        $this->add_control(
            'hover_border_heading',
            array(
                'label'      => __( 'Hover', 'clever-woo-builder' ),
                'type'       => Controls_Manager::HEADING,
                'separator' => 'after',
            )
        );
        $this->add_control('hover_color', [
            'label' => esc_html__('Hover Color', 'clever-woo-builder'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .cwb-cart-extend-info a:hover' => 'color: {{COLOR}}',
            ],
        ]);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'        => 'hover_border',
				'label'       => esc_html__( 'Hover Border', 'clever-woo-builder' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .cwb-cart-extend-info-item a:hover',
			)
		);

		$this->add_responsive_control(
			'content_padding',
			array(
				'label'      => __( 'Padding', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
                'separator' => 'before',
				'selectors'  => array(
					'{{WRAPPER}} .cwb-cart-extend-info-item a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
        $this->add_responsive_control('space', [
            'label' => esc_html__('Space', 'clever-woo-builder'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 1,
                    'max' => 100,
                ],
            ],
            'devices' => ['desktop', 'tablet', 'mobile'],
            'desktop_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'tablet_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'mobile_default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'selectors'  => array(
                '{{WRAPPER}} .cwb-cart-extend-info-item' => 'margin-right: {{SIZE}}{{UNIT}};',
            ),
        ]);

		$this->end_controls_section();

	}

	protected function render() {

		$this->__context = 'render';

		if ( true === $this->__set_editor_product() ) {
			$this->__open_wrap();
			include $this->__get_global_template( 'index' );
			$this->__close_wrap();
			$this->__reset_editor_product();
		}

	}
}
