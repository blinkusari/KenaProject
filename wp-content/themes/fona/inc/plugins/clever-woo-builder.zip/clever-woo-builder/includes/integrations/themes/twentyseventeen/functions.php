<?php
/**
 * Twenty Seventeen integration
 */

add_action( 'elementor/page_templates/canvas/before_content', 'clever_woo_twenty_seventeen_open_site_main_wrap', - 999 );
add_action( 'clever-woo-builder/blank-page/before-content', 'clever_woo_twenty_seventeen_open_site_main_wrap', - 999 );
add_action( 'elementor/page_templates/header-footer/before_content', 'clever_woo_twenty_seventeen_open_site_main_wrap', - 999 );
add_action( 'clever-woo-builder/full-width-page/before-content', 'clever_woo_twenty_seventeen_open_site_main_wrap', - 999 );

add_action( 'elementor/page_templates/canvas/after_content', 'clever_woo_twenty_seventeen_close_site_main_wrap', 999 );
add_action( 'clever-woo-builder/blank-page/after_content', 'clever_woo_twenty_seventeen_close_site_main_wrap', 999 );
add_action( 'elementor/page_templates/header-footer/after_content', 'clever_woo_twenty_seventeen_close_site_main_wrap', 999 );
add_action( 'clever-woo-builder/full-width-page/after_content', 'clever_woo_twenty_seventeen_close_site_main_wrap', 999 );

add_action( 'wp_enqueue_scripts', 'clever_woo_twenty_seventeen_enqueue_styles' );


/**
 * Open .site-main wrapper for products
 * @return [type] [description]
 */
function clever_woo_twenty_seventeen_open_site_main_wrap() {
	if ( ! is_singular( array( clever_woo_builder_post_type()->slug(), 'product' ) ) ) {
		return;
	}

	echo '<div class="site-main">';
}

/**
 * Close .site-main wrapper for products
 * @return [type] [description]
 */
function clever_woo_twenty_seventeen_close_site_main_wrap() {

	if ( ! is_singular( array( clever_woo_builder_post_type()->slug(), 'product' ) ) ) {
		return;
	}

	echo '</div>';
}


/**
 * Enqueue Twenty Fifteen integration stylesheets.
 *
 * @since 1.0.0
 * @access public
 * @return void
 */
function clever_woo_twenty_seventeen_enqueue_styles() {
	wp_enqueue_style(
		'clever-woo-builder-twentyseventeen',
		clever_woo_builder()->plugin_url( 'includes/integrations/themes/twentyseventeen/assets/css/style.css' ),
		false,
		clever_woo_builder()->get_version()
	);
}