<?php
/**
 * WooCommerce Product Settings
 *
 * @author   WooThemes
 * @category Admin
 * @package  WooCommerce/Admin
 * @version  2.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Clever_Woo_Builder_Shop_Settings_Page.
 */
class Clever_Woo_Builder_Shop_Settings_Page extends WC_Settings_Page {

	/**
	 * Constructor.
	 */
	public function __construct() {

		$this->id    = clever_woo_builder_shop_settings()->key;
		$this->label = __( 'Clever Woo Builder', 'clever-woo-builder' );

		parent::__construct();
	}

	/**
	 * Get sections.
	 *
	 * @return array
	 */
	public function get_sections() {
		$sections = array(
			'' => __( 'General', 'clever-woo-builder' ),
		);

		return apply_filters( 'woocommerce_get_sections_' . $this->id, $sections );
	}

	/**
	 * Output the settings.
	 */
	public function output() {
		global $current_section;
		$settings = $this->get_settings( $current_section );

		WC_Admin_Settings::output_fields( $settings );
	}

	/**
	 * Save settings.
	 */
	public function save() {
		global $current_section;

		$settings = $this->get_settings( $current_section );

		WC_Admin_Settings::save_fields( $settings );

	}

	/**
	 * Get settings array.
	 *
	 * @param string $current_section Current section name.
	 *
	 * @return array
	 */
	public function get_settings( $current_section = '' ) {
		global $current_section;

		$settings = array(
			array(
				'title' => __( 'General', 'clever-woo-builder' ),
				'type'  => 'title',
				'desc'  => '',
				'id'    => 'general_options',
			),

			array(
				'title'    => __( 'Widgets Render Method', 'clever-woo-builder' ),
				'desc'     => __( 'Select widgets render method for archive product, archive category, cart, checkout, thank you and my account templates', 'clever-woo-builder' ),
				'id'       => clever_woo_builder_shop_settings()->options_key . '[widgets_render_method]',
				'default'  => 'macros',
				'type'     => 'clever_woo_select_render_method_field',
				'class'    => 'wc-enhanced-select-nostd',
				'css'      => 'min-width:300px;',
			),

			array(
				'type' => 'sectionend',
				'id'   => 'general_options',
			),

			array(
				'title' => __( 'Shop Page', 'clever-woo-builder' ),
				'type'  => 'title',
				'desc'  => '',
				'id'    => 'shop_options',
			),

			array(
				'title'   => __( 'Custom Shop Page', 'clever-woo-builder' ),
				'desc'    => __( 'Enable custom shop page', 'clever-woo-builder' ),
				'id'      => clever_woo_builder_shop_settings()->options_key . '[custom_shop_page]',
				'default' => '',
				'type'    => 'checkbox',
			),

			array(
				'title'    => __( 'Shop Template', 'clever-woo-builder' ),
				'desc'     => __( 'Select template to use it as global shop template', 'clever-woo-builder' ),
				'id'       => clever_woo_builder_shop_settings()->options_key . '[shop_template]',
				'doc_type' => 'shop',
				'default'  => '',
				'type'     => 'clever_woo_select_template',
				'class'    => 'wc-enhanced-select-nostd',
				'css'      => 'min-width:300px;',
			),

			array(
				'title'   => __( 'Custom Taxonomy Template', 'clever-woo-builder' ),
				'desc'    => __( 'Enable custom taxonomy template. Read more about custom template <a href="https://cleveraddon.com/knowledge-base/articles/cleverwoobuilder-how-to-set-up-a-custom-product-taxonomy-template/" target="_blank" rel="nofollow">here</a>', 'clever-woo-builder' ),
				'id'      => clever_woo_builder_shop_settings()->options_key . '[custom_taxonomy_template]',
				'default' => '',
				'type'    => 'checkbox',
			),

			array(
				'type' => 'sectionend',
				'id'   => 'shop_options',
			),

			array(
				'title' => __( 'Single Product', 'clever-woo-builder' ),
				'type'  => 'title',
				'desc'  => '',
				'id'    => 'single_options',
			),

			array(
				'title'   => __( 'Custom Single Product', 'clever-woo-builder' ),
				'desc'    => __( 'Enable custom single product page', 'clever-woo-builder' ),
				'id'      => clever_woo_builder_shop_settings()->options_key . '[custom_single_page]',
				'default' => '',
				'type'    => 'checkbox',
			),

			array(
				'title'    => __( 'Single Product Template', 'clever-woo-builder' ),
				'desc'     => __( 'Select template to use it as global single product template', 'clever-woo-builder' ),
				'id'       => clever_woo_builder_shop_settings()->options_key . '[single_template]',
				'doc_type' => 'single',
				'default'  => '',
				'type'     => 'clever_woo_select_template',
				'class'    => 'wc-enhanced-select-nostd',
				'css'      => 'min-width:300px;',
			),

			array(
				'type' => 'sectionend',
				'id'   => 'single_options',
			),

			array(
				'title' => __( 'Archive Product', 'clever-woo-builder' ),
				'type'  => 'title',
				'desc'  => '',
				'id'    => 'archive_options',
			),

			array(
				'title'   => __( 'Custom Archive Product', 'clever-woo-builder' ),
				'desc'    => __( 'Enable custom archive product', 'clever-woo-builder' ),
				'id'      => clever_woo_builder_shop_settings()->options_key . '[custom_archive_page]',
				'default' => '',
				'type'    => 'checkbox',
			),

			array(
				'title'    => __( 'Archive Product Template', 'clever-woo-builder' ),
				'desc'     => __( 'Select template to use it as global archive product template', 'clever-woo-builder' ),
				'id'       => clever_woo_builder_shop_settings()->options_key . '[archive_template]',
				'doc_type' => 'archive',
				'default'  => '',
				'type'     => 'clever_woo_select_template',
				'class'    => 'wc-enhanced-select-nostd',
				'css'      => 'min-width:300px;',
			),

			array(
				'title'    => __( 'Search Page Template', 'clever-woo-builder' ),
				'desc'     => __( 'Select template to use it as global cross search page template', 'clever-woo-builder' ),
				'id'       => clever_woo_builder_shop_settings()->options_key . '[search_template]',
				'doc_type' => 'archive',
				'default'  => '',
				'type'     => 'clever_woo_select_template',
				'class'    => 'wc-enhanced-select-nostd',
				'css'      => 'min-width:300px;',
			),

			array(
				'title'    => __( 'Product Shortcode Template', 'clever-woo-builder' ),
				'desc'     => __( 'Select template to use it as global product shortcode template', 'clever-woo-builder' ),
				'id'       => clever_woo_builder_shop_settings()->options_key . '[shortcode_template]',
				'doc_type' => 'archive',
				'default'  => '',
				'type'     => 'clever_woo_select_template',
				'class'    => 'wc-enhanced-select-nostd',
				'css'      => 'min-width:300px;',
			),

			array(
				'title'    => __( 'Related and Up Sells Products Template', 'clever-woo-builder' ),
				'desc'     => __( 'Select template to use it as global related products template', 'clever-woo-builder' ),
				'id'       => clever_woo_builder_shop_settings()->options_key . '[related_template]',
				'doc_type' => 'archive',
				'default'  => '',
				'type'     => 'clever_woo_select_template',
				'class'    => 'wc-enhanced-select-nostd',
				'css'      => 'min-width:300px;',
			),

			array(
				'title'    => __( 'Cross Sells Product Template', 'clever-woo-builder' ),
				'desc'     => __( 'Select template to use it as global cross sells product template', 'clever-woo-builder' ),
				'id'       => clever_woo_builder_shop_settings()->options_key . '[cross_sells_template]',
				'doc_type' => 'archive',
				'default'  => '',
				'type'     => 'clever_woo_select_template',
				'class'    => 'wc-enhanced-select-nostd',
				'css'      => 'min-width:300px;',
			),

			array(
				'type' => 'sectionend',
				'id'   => 'archive_options',
			),

			array(
				'title' => __( 'Archive Category', 'clever-woo-builder' ),
				'type'  => 'title',
				'desc'  => '',
				'id'    => 'categories_options',
			),

			array(
				'title'   => __( 'Custom Archive Category', 'clever-woo-builder' ),
				'desc'    => __( 'Enable custom archive category', 'clever-woo-builder' ),
				'id'      => clever_woo_builder_shop_settings()->options_key . '[custom_archive_category_page]',
				'default' => '',
				'type'    => 'checkbox',
			),

			array(
				'title'    => __( 'Archive Category Template', 'clever-woo-builder' ),
				'desc'     => __( 'Select template to use it as global archive category template', 'clever-woo-builder' ),
				'id'       => clever_woo_builder_shop_settings()->options_key . '[category_template]',
				'doc_type' => 'category',
				'default'  => '',
				'type'     => 'clever_woo_select_template',
				'class'    => 'wc-enhanced-select-nostd',
				'css'      => 'min-width:300px;',
			),

			array(
				'type' => 'sectionend',
				'id'   => 'categories_options',
			),

			array(
				'title' => __( 'Cart', 'clever-woo-builder' ),
				'type'  => 'title',
				'desc'  => '',
				'id'    => 'cart_options',
			),

			array(
				'title'   => __( 'Custom Cart', 'clever-woo-builder' ),
				'desc'    => __( 'Enable custom cart', 'clever-woo-builder' ),
				'id'      => clever_woo_builder_shop_settings()->options_key . '[custom_cart_page]',
				'default' => '',
				'type'    => 'checkbox',
			),

			array(
				'title'    => __( 'Cart Template', 'clever-woo-builder' ),
				'desc'     => __( 'Select template to use it as cart template', 'clever-woo-builder' ),
				'id'       => clever_woo_builder_shop_settings()->options_key . '[cart_template]',
				'doc_type' => 'cart',
				'default'  => '',
				'type'     => 'clever_woo_select_template',
				'class'    => 'wc-enhanced-select-nostd',
				'css'      => 'min-width:300px;',
			),

			array(
				'title'    => __( 'Empty Cart Template', 'clever-woo-builder' ),
				'desc'     => __( 'Select template to use it as empty cart template', 'clever-woo-builder' ),
				'id'       => clever_woo_builder_shop_settings()->options_key . '[empty_cart_template]',
				'doc_type' => 'cart',
				'default'  => '',
				'type'     => 'clever_woo_select_template',
				'class'    => 'wc-enhanced-select-nostd',
				'css'      => 'min-width:300px;',
			),

			array(
				'type' => 'sectionend',
				'id'   => 'cart_options',
			),

			array(
				'title' => __( 'Checkout', 'clever-woo-builder' ),
				'type'  => 'title',
				'desc'  => '',
				'id'    => 'checkout_options',
			),

			array(
				'title'   => __( 'Custom Checkout', 'clever-woo-builder' ),
				'desc'    => __( 'Enable custom checkout', 'clever-woo-builder' ),
				'id'      => clever_woo_builder_shop_settings()->options_key . '[custom_checkout_page]',
				'default' => '',
				'type'    => 'checkbox',
			),

			array(
				'title'    => __( 'Checkout Template', 'clever-woo-builder' ),
				'desc'     => __( 'Select template to use it as checkout template', 'clever-woo-builder' ),
				'id'       => clever_woo_builder_shop_settings()->options_key . '[checkout_template]',
				'doc_type' => 'checkout',
				'default'  => '',
				'type'     => 'clever_woo_select_template',
				'class'    => 'wc-enhanced-select-nostd',
				'css'      => 'min-width:300px;',
			),

			array(
				'title'    => __( 'Checkout Top Template', 'clever-woo-builder' ),
				'desc'     => __( 'Select template to use it as checkout top content template (E.g: Coupon form, login form etc.)', 'clever-woo-builder' ),
				'id'       => clever_woo_builder_shop_settings()->options_key . '[checkout_top_template]',
				'doc_type' => 'checkout',
				'default'  => '',
				'type'     => 'clever_woo_select_template',
				'class'    => 'wc-enhanced-select-nostd',
				'css'      => 'min-width:300px;',
			),

			array(
				'type' => 'sectionend',
				'id'   => 'checkout_options',
			),

			array(
				'title' => __( 'Thank You Page', 'clever-woo-builder' ),
				'type'  => 'title',
				'desc'  => '',
				'id'    => 'thankyou_options',
			),

			array(
				'title'   => __( 'Custom Thank You Page', 'clever-woo-builder' ),
				'desc'    => __( 'Enable custom thank you page', 'clever-woo-builder' ),
				'id'      => clever_woo_builder_shop_settings()->options_key . '[custom_thankyou_page]',
				'default' => '',
				'type'    => 'checkbox',
			),

			array(
				'title'    => __( 'Thank You Template', 'clever-woo-builder' ),
				'desc'     => __( 'Select template to use it as thank you template', 'clever-woo-builder' ),
				'id'       => clever_woo_builder_shop_settings()->options_key . '[thankyou_template]',
				'doc_type' => 'thankyou',
				'default'  => '',
				'type'     => 'clever_woo_select_template',
				'class'    => 'wc-enhanced-select-nostd',
				'css'      => 'min-width:300px;',
			),

			array(
				'type' => 'sectionend',
				'id'   => 'myaccount_options',
			),

			array(
				'title' => __( 'My Account Page', 'clever-woo-builder' ),
				'type'  => 'title',
				'desc'  => '',
				'id'    => 'myaccount_options',
			),

			array(
				'title'   => __( 'Custom My Account Page', 'clever-woo-builder' ),
				'desc'    => __( 'Enable custom my account page', 'clever-woo-builder' ),
				'id'      => clever_woo_builder_shop_settings()->options_key . '[custom_myaccount_page]',
				'default' => '',
				'type'    => 'checkbox',
			),

			array(
				'title'    => __( 'My Account Template', 'clever-woo-builder' ),
				'desc'     => __( 'Select template to use it as my account template', 'clever-woo-builder' ),
				'id'       => clever_woo_builder_shop_settings()->options_key . '[myaccount_template]',
				'doc_type' => 'myaccount',
				'default'  => '',
				'type'     => 'clever_woo_select_template',
				'class'    => 'wc-enhanced-select-nostd',
				'css'      => 'min-width:300px;',
			),

			array(
				'title'    => __( 'My Account Login Page Template', 'clever-woo-builder' ),
				'desc'     => __( 'Select template to use it as login page template (E.g: Registration form, login form etc.)', 'clever-woo-builder' ),
				'id'       => clever_woo_builder_shop_settings()->options_key . '[form_login_template]',
				'doc_type' => 'myaccount',
				'default'  => '',
				'type'     => 'clever_woo_select_template',
				'class'    => 'wc-enhanced-select-nostd',
				'css'      => 'min-width:300px;',
			),

			array(
				'type' => 'sectionend',
				'id'   => 'myaccount_options',
			),

			array(
				'title' => __( 'Other Options', 'clever-woo-builder' ),
				'type'  => 'title',
				'desc'  => '',
				'id'    => 'other_options',
			),

			array(
				'title'   => __( 'Use AJAX Add to Cart', 'clever-woo-builder' ),
				'desc'    => __( 'Force use AJAX add to cart instead of page reload on the single product page', 'clever-woo-builder' ),
				'id'      => clever_woo_builder_shop_settings()->options_key . '[use_ajax_add_to_cart]',
				'default' => '',
				'type'    => 'checkbox',
			),

			array(
				'title'   => __( 'Use Native Templates', 'clever-woo-builder' ),
				'desc'    => __( 'Force use native WooCommerce templates instead of rewritten in theme', 'clever-woo-builder' ),
				'id'      => clever_woo_builder_shop_settings()->options_key . '[use_native_templates]',
				'default' => '',
				'type'    => 'checkbox',
			),

			array(
				'title'   => __( 'Number related products to show', 'clever-woo-builder' ),
				'id'      => clever_woo_builder_shop_settings()->options_key . '[related_products_per_page]',
				'type'    => 'number',
				'default' => 4,
				'step'    => 1,
				'min'     => 1,
				'max'     => '',
				'std'     => 10,
			),

			array(
				'title'   => __( 'Number up sells products to show', 'clever-woo-builder' ),
				'id'      => clever_woo_builder_shop_settings()->options_key . '[up_sells_products_per_page]',
				'type'    => 'number',
				'default' => 4,
				'step'    => 1,
				'min'     => 1,
				'max'     => '',
				'std'     => 10,
			),

			array(
				'title'   => __( 'Number cross sells products to show', 'clever-woo-builder' ),
				'id'      => clever_woo_builder_shop_settings()->options_key . '[cross_sells_products_per_page]',
				'type'    => 'number',
				'default' => 4,
				'step'    => 1,
				'min'     => 1,
				'max'     => '',
				'std'     => 10,
			),

			array(
				'type' => 'sectionend',
				'id'   => 'other_options',
			),
		);

		return apply_filters( 'woocommerce_get_settings_' . $this->id, $settings, $current_section );
	}
}
