<?php
/**
 * Class: Clever_Woo_Builder_Single_New_Label
 * Name: Single New Label
 * Slug: clever-single-new-label
 */

namespace Elementor;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;
use Elementor\Core\Schemes\Color;
use Elementor\Widget_Base;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

class Clever_Woo_Builder_Single_New_Label extends Clever_Woo_Builder_Base {

	public function get_name() {
		return 'clever-single-new-label';
	}

	public function get_title() {
		return esc_html__( 'Single New Label', 'clever-woo-builder' );
	}

	public function get_icon() {
		return 'clever-woo-builder-icon-archive-stock-status';
	}

	public function get_script_depends() {
		return array();
	}

	public function get_categories() {
		return array( 'clever-woo-builder' );
	}

	public function show_in_panel() {
		return clever_woo_builder()->documents->is_document_type( 'single' );
	}

	protected function register_controls() {

		$this->start_controls_section(
			'section_single_new_label_style',
			array(
				'label'      => esc_html__( 'Style', 'clever-woo-builder' ),
				'tab'        => Controls_Manager::TAB_STYLE,
				'show_label' => false,
			)
		);

		$this->add_control(
			'single_new_label_color',
			array(
				'label'     => esc_html__( 'Apply only for Clever themes', 'clever-woo-builder' ),
				'type'      => Controls_Manager::HEADING,
			)
		);
		$this->add_control(
			'single_new_label_color',
			array(
				'label'     => esc_html__( 'Color', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .in-stock' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_control(
			'single_new_label_background',
			array(
				'label'     => esc_html__( 'Background', 'clever-woo-builder' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .in-stock' => 'background-color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'single_new_label_typography',
				'selector' => '{{WRAPPER}} .in-stock'
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'        => 'single_new_label_border',
				'label'       => esc_html__( 'Border', 'clever-woo-builder' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .in-stock',
			)
		);

		$this->add_responsive_control(
			'single_new_label_border_radius',
			array(
				'label'      => __( 'Border Radius', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .in-stock' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'single_new_label_box_shadow',
				'selector' => '{{WRAPPER}} .in-stock',
			)
		);

		$this->add_responsive_control(
			'single_new_label_content_padding',
			array(
				'label'      => __( 'Padding', 'clever-woo-builder' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .in-stock' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
		$this->end_controls_section();
	}

	protected function render() {

		$this->__context = 'render';

		if ( true === $this->__set_editor_product() ) {
			$this->__open_wrap();
			include $this->__get_global_template( 'index' );
			$this->__close_wrap();
			$this->__reset_editor_product();
		}

	}
}
