<?php
/**
 * Main dashboard template
 */
?><div id="clever-dashboard-page" class="clever-dashboard-page">
	<clever-dashboard-header></clever-dashboard-header>
	<div class="clever-dashboard-page__content">
		<component
		:is="page"
		></component>
	</div>
</div>
